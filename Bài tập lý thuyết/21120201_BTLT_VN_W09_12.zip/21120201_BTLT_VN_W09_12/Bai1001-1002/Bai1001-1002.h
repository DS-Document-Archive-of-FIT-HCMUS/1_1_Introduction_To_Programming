#ifndef _BAI1002_H_
#define _BAI1002_H_
#endif
#include <stdio.h>
#include <math.h>
#include <cmath>
#define MAX 100
struct point2D {
	double x;
	double y;
};
struct cacTamGiac {
	point2D dinh1;
	point2D dinh2;
	point2D dinh3;
};
void inputPoint(FILE* f, point2D& p);
void inputTriangle(FILE* f, cacTamGiac& tamgiac);
void xuatTamGiac(FILE* f, cacTamGiac tamgiac);
double doDaiCanh(point2D p1, point2D p2);
bool kiemTraTamGiac(cacTamGiac tamgiac);
double chuViTamGiac(cacTamGiac tamgiac);
void nhapMangTamGiac(FILE* f, cacTamGiac tamgiac[], int& n);
void timTamGiacCoChuViLonNhat(FILE* f, cacTamGiac tamgiac[], int n);
