#include "bai1001-1002.h"
int main() {
	cacTamGiac tamgiac[MAX];
	int n{};
	FILE* fp1;
	fopen_s(&fp1, "filein.txt", "rt");
	if (fp1 == NULL) {
		printf("Khong the mo file!\n");
	}
	else {
		nhapMangTamGiac(fp1, tamgiac, n);
		fclose(fp1);
	}
	FILE* fp2;
	fopen_s(&fp2, "fileout.txt", "wt");
	if (fp2 != NULL) {
		timTamGiacCoChuViLonNhat(fp1, tamgiac, n);
		fflush(fp2);
		fclose(fp2);
	}
	return 0;
}