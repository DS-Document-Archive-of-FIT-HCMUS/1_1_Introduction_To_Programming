#include "bai581-585.h"
void inputPoint(FILE* f, point2D& p) {
	fscanf_s(f, "%lf", &p.x);
	fscanf_s(f, "%lf", &p.y);
}
void inputTriangle(FILE* f, cacTamGiac& tamgiac) {
	inputPoint(f, tamgiac.dinh1);
	inputPoint(f, tamgiac.dinh2);
	inputPoint(f, tamgiac.dinh3);
}
void xuatTamGiac(FILE* f, cacTamGiac tamgiac) {
	fprintf(f,"Tam giac la: ((%0.3lf,%0.3lf);(%0.3lf,%0.3lf);(%0.3lf,%0.3lf))\n", tamgiac.dinh1.x, tamgiac.dinh1.y, tamgiac.dinh2.x, tamgiac.dinh2.y, tamgiac.dinh3.x, tamgiac.dinh3.y);
}
double doDaiCanh(point2D p1, point2D p2) {
	return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
bool kiemTraTamGiac(cacTamGiac tamgiac) {
	double d1 = doDaiCanh(tamgiac.dinh1, tamgiac.dinh2),
		d2 = doDaiCanh(tamgiac.dinh2, tamgiac.dinh3),
		d3 = doDaiCanh(tamgiac.dinh3, tamgiac.dinh1);
	if ((d1 + d2) > d3 && d3 > abs(d1 - d2) && d1 > 0 && d2 > 0 && d3 > 0) {
		return 1;
	}
	else {
		return 0;
	}
}
double chuViTamGiac(cacTamGiac tamgiac) {
	return doDaiCanh(tamgiac.dinh1, tamgiac.dinh2) + doDaiCanh(tamgiac.dinh2, tamgiac.dinh3) + doDaiCanh(tamgiac.dinh3, tamgiac.dinh1);
}