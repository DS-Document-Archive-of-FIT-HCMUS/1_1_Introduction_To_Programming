#include "bai581-585.h"
int main() {
	cacTamGiac tamgiac{};
	FILE* fp1;
	fopen_s(&fp1, "filein.txt", "rt");
	if (fp1 == NULL) {
		printf("Khong the mo file!\n");
	}
	else {
		inputTriangle(fp1, tamgiac);
		fclose(fp1);
	}
	FILE* fp2;
	fopen_s(&fp2, "fileout.txt", "wt");
	if (fp2 != NULL) {
		xuatTamGiac(fp2, tamgiac);
		if (kiemTraTamGiac(tamgiac)) {
			fprintf(fp2, "La 3 dinh cua tam giac!\n");
			fprintf(fp2, "Chu vi tam giac la: %lf", chuViTamGiac(tamgiac));
		}
		else {
			fprintf(fp2, "KHONG la 3 dinh cua tam giac!\n");
		}
	}
	return 0;
}