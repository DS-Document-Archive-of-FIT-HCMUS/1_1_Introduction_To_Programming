#include "Bai667.h"
void nhap1Tinh(FILE* f, cacTinh& t) {
	fscanf_s(f, "%d", &t.maTinh);
	fgets(t.tenTinh, 31, f);
	fgets(t.tenTinh, 31, f);
	fscanf_s(f, "%d", &t.danSo);
	fscanf_s(f, "%lf", &t.dienTich);
}
void nhapTinh(FILE* f, cacTinh t[], int& n) {
	fscanf_s(f, "%d", &n);
	for (int i = 0; i < n; i++) {
		nhap1Tinh(f, t[i]);
	}
}
void xuat1Tinh(FILE* f, cacTinh t) {
	fprintf(f, "%d - %s - %d - %lf \n", t.maTinh, t.tenTinh, t.danSo, t.dienTich);
}
void xuatTinh(FILE* f, cacTinh t[], int n) {
	for (int i = 0; i < n; i++) {
		xuat1Tinh(f, t[i]);
	}
}
//Cau a
void dsTinhLonHon1M(FILE* f, cacTinh t[], int n) {
	for (int i = 0; i < n; i++) {
		if (t[i].danSo > 1000000) {
			xuat1Tinh(f, t[i]);
		}
	}
}
//Cau b
cacTinh STinhMax(cacTinh t[], int n) {
	cacTinh s = t[0];
	double Smax = t[0].dienTich;
	for (int i = 1; i < n; i++) {
		if (t[i].dienTich > Smax) {
			Smax = t[i].dienTich;
			s = t[i];
		}
	}
	return s;
}
//Cau c
void sapXepGiamS(cacTinh t[], int n) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n; j++) {
			if (t[i].dienTich < t[j].dienTich) {
				cacTinh temp = t[i];
				t[i] = t[j];
				t[j] = temp;
			}
		}
	}
}
