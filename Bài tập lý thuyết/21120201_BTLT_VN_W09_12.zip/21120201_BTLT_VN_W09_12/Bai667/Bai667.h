#ifndef _BAI667_H_
#define _BAI667_H_
#endif
#include <stdio.h>
using namespace std;
#define MAX 100
struct cacTinh {
	int maTinh;
	char tenTinh[31];
	int danSo;
	double dienTich;
};
void nhap1Tinh(FILE* f, cacTinh& t);
void nhapTinh(FILE* f, cacTinh t[], int& n);
void xuat1Tinh(FILE* f, cacTinh t);
void xuatTinh(FILE* f, cacTinh t[], int n);
//Cau a
void dsTinhLonHon1M(FILE* f, cacTinh t[], int n);
//Cau b
cacTinh STinhMax(cacTinh t[], int n);
//Cau c
void sapXepGiamS(cacTinh t[], int n);