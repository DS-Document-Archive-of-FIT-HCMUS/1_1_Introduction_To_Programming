#include "Bai667.h"
int main() {
	cacTinh Tinh[MAX]{};
	int n{};
	FILE* fp1;
	fopen_s(&fp1, "filein.txt", "rt");
	if (fp1 == NULL) {
		printf("Khong the mo file!\n");
	}
	else {
		nhapTinh(fp1, Tinh, n);
		fclose(fp1);
	}
	FILE* fp2;
	fopen_s(&fp2, "fileout.txt", "wt");
	if (fp2 != NULL) {
		//Cau a
		fprintf(fp2, "\n");
		fprintf(fp2, "Cac tinh co dan so lon hon 1.000.000 la: \n");
		dsTinhLonHon1M(fp2, Tinh, n);
		fprintf(fp2, "\n");
		//Cau b
		fprintf(fp2, "Mot tinh co dien tich lon nhat la: ");
		fprintf(fp2, STinhMax(Tinh, n).tenTinh);
		fprintf(fp2, "\n\n");
		//Cau c
		sapXepGiamS(Tinh, n);
		fprintf(fp2, "Mang cac tinh sau khi da sap xep dien tich giam dan la\n");
		xuatTinh(fp2, Tinh, n);
		fflush(fp2);
		fclose(fp2);
	}
	
	return 0;
}