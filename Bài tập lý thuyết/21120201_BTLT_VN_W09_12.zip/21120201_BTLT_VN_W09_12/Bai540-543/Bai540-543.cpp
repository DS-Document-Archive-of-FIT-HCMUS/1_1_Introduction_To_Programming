#include "bai540-543.h"
void inputPoint(FILE* f, point2D& p) {
	fscanf_s(f, "%lf", &p.x);
	fscanf_s(f, "%lf", &p.y);
}
void outputPoint(FILE* f, point2D p) {
	fprintf(f, "(%0.3lf,%0.3lf)\n", p.x, p.y);
}
double khoangCach(point2D p1, point2D p2) {
	return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
