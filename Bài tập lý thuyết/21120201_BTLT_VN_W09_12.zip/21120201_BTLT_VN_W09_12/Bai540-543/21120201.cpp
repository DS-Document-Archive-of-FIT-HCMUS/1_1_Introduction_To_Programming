#include "bai540-543.h"
int main() {
	point2D pointA{}, pointB{};
	FILE* fp1;
	fopen_s(&fp1, "filein.txt", "rt");
	if (fp1 == NULL) {
		printf("Mo file khong thanh cong!");
	}
	else {
		inputPoint(fp1, pointA);
		inputPoint(fp1, pointB);
		fclose(fp1);
	}
	FILE* fp2;
	fopen_s(&fp2, "fileout.txt", "wt");
	if (fp2 != 0) {
		fprintf(fp2, "Toa do diem A la:\n");
		outputPoint(fp2, pointA);
		fprintf(fp2, "Toa do diem B la:\n");
		outputPoint(fp2, pointB);
		fprintf(fp2, "Khoang cach giua 2 diem A va B la: %lf", khoangCach(pointA, pointB));
		fflush(fp2);
		fclose(fp2);
	}
	return 0;
} 