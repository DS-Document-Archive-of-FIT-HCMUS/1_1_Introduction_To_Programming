#ifndef _BAI540543_H_
#define _BAI540543_H_
#endif 
#include <stdio.h>
#include <math.h>
using namespace std;
#define MAX 100
struct point2D {
	double x;
	double y;
}typedef pointA, pointB;
void inputPoint(FILE* f, point2D& p);
void outputPoint(FILE* f, point2D p);
double khoangCach(point2D p1, point2D p2);