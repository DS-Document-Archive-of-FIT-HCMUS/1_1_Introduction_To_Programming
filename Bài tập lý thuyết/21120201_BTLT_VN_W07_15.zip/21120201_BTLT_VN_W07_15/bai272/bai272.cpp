#include "bai272.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%lf", &a[i]);
	}
}
void xuatMang(double a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%lf ", a[i]);
	}
	printf("\n");
}
double timMax(double a[], int n) {
	double max = a[0];
	for (int i = 1; i < n; i++) {
		if (a[i] > max) {
			max = a[i];
		}
	}
	return max;
}
void xoa1ViTri(double a[], int& n, int k) {
	for (int i = k; i < n; i++) {
		a[i] = a[i + 1];
	}
	n--;
}
void xoaLonNhat(double a[], int& n) {
	double max = timMax(a, n);
	for (int i = 0; i < n; i++) {
		if (a[i] == max) {
			xoa1ViTri(a, n, i);
			i--;
		}
	}
}

