#include "bai272.h"
int main() {
	double a[MAX];
	int n;
	nhapMang(a, n);
	xuatMang(a, n);
	xoaLonNhat(a, n);
	printf("Sau khi xoa cac vi tri co gia tri lon nhat, ");
	xuatMang(a, n);
	return 0;
}