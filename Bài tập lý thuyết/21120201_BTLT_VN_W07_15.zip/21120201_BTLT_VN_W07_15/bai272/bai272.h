#ifndef _bai272_H_
#define _bai272_H_
#endif 
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <iomanip>
#define MAX 100
void nhapMang(double a[], int& n);
void xuatMang(double a[], int n);
double timMax(double a[], int n);
void xoa1ViTri(double a[], int& n, int k);
void xoaLonNhat(double a[], int& n);
