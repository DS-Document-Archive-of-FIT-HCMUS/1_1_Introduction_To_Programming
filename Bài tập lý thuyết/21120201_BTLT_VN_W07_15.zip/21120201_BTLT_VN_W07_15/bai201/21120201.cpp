#include "bai201.h"
int main() {
	double a[MAX];
	int n;
	nhapMang(a, n);
	xuatMang(a, n);
	printf("Tong cac gia tri duong cua mang la: %lf", tongDuong(a, n));
	return 0;
}