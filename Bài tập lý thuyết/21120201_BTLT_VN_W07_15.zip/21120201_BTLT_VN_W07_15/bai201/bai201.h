#ifndef _bai201_H_
#define _bai201_H_
#endif 
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <iomanip>
#define MAX 100
void nhapMang(double a[], int& n);
void xuatMang(double a[], int n);
double tongDuong(double a[], int n);
