#include "bai255.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	sapXepTang(a, n);
	printf("Sau khi sap xep tang dan,\n");
	xuatMang(a, n);
	return 0;
}