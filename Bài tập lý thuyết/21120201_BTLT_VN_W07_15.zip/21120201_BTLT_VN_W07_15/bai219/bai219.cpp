#include "bai219.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%lf", &a[i]);
	}
}
void xuatMang(double a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%lf ", a[i]);
	}
	printf("\n");
}
int tanSuat(double a[], int n, double x) {
	int s = 0;
	for (int i = 0; i < n; i++) {
		if (a[i] == x) {
			s++;
		}
	}
	return s;
}