#include "bai219.h"
int main() {
	double a[MAX];
	int n;
	nhapMang(a, n);
	xuatMang(a, n);
	double x;
	printf("Nhap x=");
	scanf_s("%lf", &x);
	printf("So lan xuat hien cua gia tri %lf trong mang la: %d", x, tanSuat(a, n, x));
	return 0;
}