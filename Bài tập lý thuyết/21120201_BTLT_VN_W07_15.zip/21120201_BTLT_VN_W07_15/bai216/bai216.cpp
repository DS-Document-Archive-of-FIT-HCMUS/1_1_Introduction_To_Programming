#include "bai216.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%d", &a[i]);
	}
}
void xuatMang(int a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
}
int demChan(int a[], int n) {
	int s = 0;
	for (int i = 0; i < n; i++) {
		if (a[i] % 2 == 0) {
			s++;
		}
	}
	return s;
}