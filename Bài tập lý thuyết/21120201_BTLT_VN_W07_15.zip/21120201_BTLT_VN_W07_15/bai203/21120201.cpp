#include "bai203.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	printf("Tong cac gia tri co chu so hang chuc la chu so 5 la: %d", tongChuc(a, n));
	return 0;
}