#include "bai203.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%d", &a[i]);
	}
}
void xuatMang(int a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
}
int tongChuc(int a[], int n) {
	int S = 0;
	for (int i = 0; i < n; i++) {
		if (int(a[i] / 10) % 10 == 5) {
			S = S + a[i];
		}
	}
	return S;
}