#include "bai269.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	int x;
	printf("Nhap x=");
	scanf_s("%d", &x);
	sapXepTang(a, n);
	xuatMang(a, n);
	themBaoToan(a, n, x);
	printf("Sau khi sap xep tang dan va them gia tri %d ma van giu nguyen tinh don dieu tang, \n", x);
	xuatMang(a, n);
	return 0;
}