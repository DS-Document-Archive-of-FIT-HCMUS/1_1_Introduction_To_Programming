#include "bai271.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	int k;
	printf("Nhap vi tri k = ");
	scanf_s("%d", &k);
	xoaViTri(a, n, k);
	printf("Sau khi xoa phan tu co chi so %d,\n", k);
	xuatMang(a, n);
	return 0;
}