#include "bai258.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%d", &a[i]);
	}
}
void xuatMang(int a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
}
bool kiemTraNguyenTo(int n) {
	bool k = true;
	if (n < 2) {
		k = false;
	}
	else {
		int S = 0;
		for (int i = 1; i <= n; i++) {
			if (n % i == 0) {
				S++;
			}
		}
		if (S != 2) {
			k = false;
		}
	}
	return k;
}
void nguyenToTang(int a[], int n) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (a[i] > a[j] && kiemTraNguyenTo(a[i]) && kiemTraNguyenTo(a[j])) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}