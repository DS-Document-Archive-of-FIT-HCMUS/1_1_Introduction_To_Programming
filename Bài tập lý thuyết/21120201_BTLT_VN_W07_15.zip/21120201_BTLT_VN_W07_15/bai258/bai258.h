#ifndef _bai255_H_
#define _bai255_H_
#endif 
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <iomanip>
#define MAX 100
void nhapMang(int a[], int& n);
void xuatMang(int a[], int n);
bool kiemTraNguyenTo(int n);
void nguyenToTang(int a[], int n);
