#include "bai256.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	sapXepGiam(a, n);
	printf("Sau khi sap xep giam dan,\n");
	xuatMang(a, n);
	return 0;
}