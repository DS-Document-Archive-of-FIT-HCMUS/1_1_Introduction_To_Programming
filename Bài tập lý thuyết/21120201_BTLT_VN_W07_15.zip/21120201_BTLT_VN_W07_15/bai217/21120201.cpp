#include "bai217.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	printf("So luong so duong chia het cho 7 la: %d", demChiaHetBay(a, n));
	return 0;
}