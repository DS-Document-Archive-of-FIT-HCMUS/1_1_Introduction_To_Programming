#ifndef _bai267_H_
#define _bai267_H_
#endif 
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <iomanip>
#define MAX 100
void nhapMangGiamDan(double a[], int& n);
void xuatMang(double a[], int n);

