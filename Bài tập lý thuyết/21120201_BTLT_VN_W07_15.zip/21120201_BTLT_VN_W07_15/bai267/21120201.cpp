#include "bai267.h"
int main() {
	double a[MAX];
	int n;
	nhapMangGiamDan(a, n);
	xuatMang(a, n);
	return 0;
}