#include "bai267.h"
void nhapMangGiamDan(double a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%lf", &a[i]);
		for (int j = 0; j < i; j++) {
			if (a[i] > a[j]) {
				int temp = a[i];
				for (int k = i; k > j; k--) {
					a[k] = a[k - 1];
				}
				a[j] = temp;
				break;
			}
		}
	}
}
void xuatMang(double a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%lf ", a[i]);
	}
	printf("\n");
}
