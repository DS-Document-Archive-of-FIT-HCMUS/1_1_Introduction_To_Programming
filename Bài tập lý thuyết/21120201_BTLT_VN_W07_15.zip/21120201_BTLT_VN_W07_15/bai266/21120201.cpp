#include "bai266.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	int k, x;
	printf("Nhap vi tri k = ");
	scanf_s("%d", &k);
	printf("Nhap gia tri x = ");
	scanf_s("%d", &x);
	themViTri(a, n, k, x);
	printf("Sau khi them gia tri %d vao vi tri %d,", k, x);
	xuatMang(a, n);
	return 0;
}