#ifndef _bai266_H_
#define _bai266_H_
#endif 
#include <stdio.h>
#include <iostream>
#include <math.h>
#include <iomanip>
#define MAX 100
void nhapMang(int a[], int& n);
void xuatMang(int a[], int n);
void themViTri(int a[], int& n, int k, int x);