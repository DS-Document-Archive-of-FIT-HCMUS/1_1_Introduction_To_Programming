#include "bai266.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%d", &a[i]);
	}
}
void xuatMang(int a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
}
int tongGiaTri(int a[], int n) {
	int S = 0;
	for (int i = 0; i < n; i++) {
		S = S + a[i];
	}
	return S;
}
void themViTri(int a[], int& n, int k, int x) {
	for (int i = n; i > k; i--) {
		a[i] = a[i - 1];
	}
	a[k] = x;
	n++;
}