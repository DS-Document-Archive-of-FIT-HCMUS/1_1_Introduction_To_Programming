#include "bai200.h"
int main() {
	int a[MAX], n;
	nhapMang(a, n);
	xuatMang(a, n);
	printf("Tong cac gia tri cua mang la: %d", tongGiaTri(a, n));
	return 0;
}