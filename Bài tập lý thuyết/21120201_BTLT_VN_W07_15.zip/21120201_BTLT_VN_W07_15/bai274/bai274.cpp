#include "bai274.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang la: ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%d", &a[i]);
	}
}
void xuatMang(int a[], int n) {
	printf("Mang la:\n");
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
}
void xoa1ViTri(int a[], int& n, int k) {
	for (int i = k; i < n; i++) {
		a[i] = a[i + 1];
	}
	n--;
}
void xoaChan(int a[], int &n) {
	for (int i = 0; i < n; i++) {
		if (a[i] % 2 == 0) {
			xoa1ViTri(a, n, i);
			i--;
		}
	}
}