#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
int main() {
	int n;
	long S = 0;
	//INPUT
	printf("Nhap n=");
	scanf_s("%d", &n);
	//
	for (int i = 1; i < n; i++) {
		if ((n % i) == 0) {
			S = S + i;
		}
	}
	//OUTPUT
	if (n == S) {
		printf("%d la so hoan thien", n);
	}
	else {
		printf("%d khong la so hoan thien", n);
	}
	return 0;
}