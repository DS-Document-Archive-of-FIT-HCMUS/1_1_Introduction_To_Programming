#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
int main() {
	int n;	// n la so nguyen duong
	//INPUT
	printf("Nhap n=");
	scanf_s("%d", &n);
	//
	float H = 1.0 * (1.0 * sqrt(n) - (int)sqrt(n));
	//OUTPUT
	if (H == 0) {
		printf("%d la so chinh phuong", n);
	}
	else {
		printf("%d khong la so chinh phuong", n);
	}
	return 0;
}