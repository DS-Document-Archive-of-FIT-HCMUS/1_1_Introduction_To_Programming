#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
int main() {
	long n, n1;
	int S = 0, S1 = 0;
	//INPUT
	printf("Nhap n=");
	scanf_s("%ld", &n);
	//
	n1 = n;
	do {
		if ((n % 10) > S) {
			S = n % 10;
		}
		n = n - n % 10;
		n = n / 10;
	} while (n != 0);
	do {
		if (n1 % 10 == S) {
			S1++;
		}
		n1 = n1 - n1 % 10;
		n1 = n1 / 10;
	} while (n1 != 0);
	//OUTPUT
	printf("Co so luong chu so lon nhat la: %d", S1);
	return 0;
}