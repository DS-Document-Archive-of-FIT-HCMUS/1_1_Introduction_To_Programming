#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
int main() {
	long n;
	int i = 1;
	//INPUT
	printf("Nhap n=");
	scanf_s("%ld", &n);
	//
	do {
		if ((n % 10) % 2 == 1) {
			i = 0;
			break;
		}
		n = n - n % 10;
		n = n / 10;
	} while (n != 0);
	//OUTPUT
	if (i == 1) {
		printf("So da cho toan chu so chan");
	}
	else {
		printf("So da cho KHONG toan chu so chan");
	}
	return 0;
}