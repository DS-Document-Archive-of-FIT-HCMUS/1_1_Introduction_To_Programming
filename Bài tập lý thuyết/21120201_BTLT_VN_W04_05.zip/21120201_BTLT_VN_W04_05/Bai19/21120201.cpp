#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
int main() {
	int n;
	float x;
	float S = 1, L = 1;
	//INPUT
	printf("Nhap n=");
	scanf_s("%d", &n);
	printf("Nhap x=");
	scanf_s("%f", &x);
	//
	for (int i = 0; i <= n; i++) {
		S = S + pow(x, 2 * i + 1) / L;
		L = L * 2 * n * (2 * n + 1);
	}
	//OUTPUT
	printf("Ket qua S=%f", S);
	return 0;
}