#include "Xetloaitamgiac.h"
int main() {
	double a, b, c;
	//Input
	do {
		printf("Nhap theo thu tu do dai ba canh cua tam giac = ");
		scanf_s("%lf %lf %lf", &a, &b, &c);
	} while ((a <= 0) && (b <= 0) && (c <= 0));
	//Output
	Xetloaitamgiac(a, b, c);
	return 0;
}