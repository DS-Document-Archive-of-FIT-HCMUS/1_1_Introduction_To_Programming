#ifndef _Xetloaitamgiac_H_
#define _Xetloaitamgiac_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
void Xetloaitamgiac(double a, double b, double c);
