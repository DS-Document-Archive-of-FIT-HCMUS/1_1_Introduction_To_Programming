//MSSV: 21120201 - Ten: Bui Dinh Bao
//Nop bai tap ve nha W05 
#include "HamtimS.h"
int main() {
	int n;
	float x;
	//Input
	printf("Nhap n=");
	scanf_s("%d", &n);
	printf("Nhap x=");
	scanf_s("%f", &x);
	//Process
	//Output
	printf("Ket qua S=%f", S(n, x));
	return 0;
}
