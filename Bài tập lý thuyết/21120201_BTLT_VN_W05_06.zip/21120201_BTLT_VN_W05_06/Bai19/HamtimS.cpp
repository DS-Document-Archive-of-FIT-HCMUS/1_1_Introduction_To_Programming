#include "HamtimS.h"
#include "HamtimS.h"

float S(int n, float x) {
	float S = 1, L = 1;
	for (int i = 0; i <= n; i++) {
		S = S + pow(x, 2 * i + 1) / L;
		L = L * 2 * n * (2 * n + 1);
	}
	return S;
}
