#ifndef _HamtimS_H_
#define _HamtimS_H_
#endif

#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;

float S(int n, float x);
