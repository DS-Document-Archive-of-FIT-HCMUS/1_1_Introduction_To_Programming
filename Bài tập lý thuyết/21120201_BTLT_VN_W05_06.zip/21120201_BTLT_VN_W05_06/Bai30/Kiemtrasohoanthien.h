#ifndef _Kiemtrasohoanthien_H_
#define _Kiemtrasohoanthien_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
bool Kiemtrasohoanthien(int n);

