#include "Kiemtrasohoanthien.h"
bool Kiemtrasohoanthien(int n) {
	bool x;
	int S = 0;
	for (int i = 1; i < n; i++) {
		if (n % i == 0) {
			S += i;
		}
	}
	if (n == S) {
		x = true;
	}
	else {
		x = false;
	}
	return x;
}

