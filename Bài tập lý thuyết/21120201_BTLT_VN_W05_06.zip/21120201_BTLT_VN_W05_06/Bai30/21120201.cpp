//MSSV: 21120201 - Ten: Bui Dinh Bao
//Nop bai tap ve nha W05 
#include "Kiemtrasohoanthien.h"
int main() {
	int n;
	//Input
	printf("Nhap n=");
	scanf_s("%d", &n);
	//Output
	if (Kiemtrasohoanthien(n)) {
		printf("La so hoan thien");
	}
	else {
		printf("Khong la so hoan thien");
	}
	return 0;
}