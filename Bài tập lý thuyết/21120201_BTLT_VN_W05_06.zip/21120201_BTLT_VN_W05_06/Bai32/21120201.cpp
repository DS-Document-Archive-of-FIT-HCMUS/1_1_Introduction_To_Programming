//MSSV: 21120201 - Ten: Bui Dinh Bao
//Nop bai tap ve nha W05 
#include "Kiemtrasochinhphuong.h"
int main() {
	int n;	// n la so nguyen duong
	do {
		printf("Nhap n=");
		scanf_s("%d", &n);
		if (n <= 0) {
			printf("Ban phai nhap lai \n");
		}
	} while (n <= 0);
	
	if (Kiemtrasochinhphuong(n)) {
		printf("%d la so chinh phuong", n);
	}
	else {
		printf("%d khong la so chinh phuong", n);
	}
	return 0;
}