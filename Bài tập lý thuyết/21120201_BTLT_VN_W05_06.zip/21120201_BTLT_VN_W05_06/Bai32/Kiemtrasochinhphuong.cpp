#include "Kiemtrasochinhphuong.h"
bool Kiemtrasochinhphuong(int n) {
	float H = 1.0 * (1.0 * sqrt(n) - (int)sqrt(n));
	bool x;
	if (H == 0) {
		x = true;
	}
	else {
		x = false;
	}
	return x;
}