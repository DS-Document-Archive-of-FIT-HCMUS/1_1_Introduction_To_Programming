#ifndef _Kiemtrasochinhphuong_H_
#define _Kiemtrasochinhphuong_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
bool Kiemtrasochinhphuong(int n); 
