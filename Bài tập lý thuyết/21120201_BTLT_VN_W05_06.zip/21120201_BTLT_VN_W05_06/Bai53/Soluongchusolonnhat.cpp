#include "Soluongchusolonnhat.h"
int Soluongchusolonnhat(long n) {
	long n1 = n;
	int S = 0, S1 = 0;
	do {
		if ((n % 10) > S) {
			S = n % 10;
		}
		n = n - n % 10;
		n = n / 10;
	} while (n != 0);
	do {
		if (n1 % 10 == S) {
			S1++;
		}
		n1 = n1 - n1 % 10;
		n1 = n1 / 10;
	} while (n1 != 0);
	return S1;
}