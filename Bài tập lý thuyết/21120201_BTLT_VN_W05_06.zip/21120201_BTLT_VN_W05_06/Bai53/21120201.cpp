//MSSV: 21120201 - Ten: Bui Dinh Bao
//Nop bai tap ve nha W05 #include "Soluongchusolonnhat.h"
int main() {
	long n;
	//Input
	printf("Nhap n=");
	scanf_s("%ld", &n);
	//Output
	printf("Co so luong chu so lon nhat la: %d", Soluongchusolonnhat(n));
	return 0;
}