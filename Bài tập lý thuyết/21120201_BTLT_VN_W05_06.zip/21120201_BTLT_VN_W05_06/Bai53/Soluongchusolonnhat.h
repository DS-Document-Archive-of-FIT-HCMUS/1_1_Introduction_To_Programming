#ifndef _Soluongchusolonnhat_H_
#define _Soluongchusolonnhat_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
int Soluongchusolonnhat(long n);
