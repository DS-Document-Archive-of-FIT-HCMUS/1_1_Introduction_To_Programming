//MSSV: 21120201 - Ten: Bui Dinh Bao
//Nop bai tap ve nha W05 
#include "Kiemtratoanchusochan.h"
int main() {
	long n;
	//Input
	printf("Nhap n=");
	scanf_s("%ld", &n);
	//Output
	if (Kiemtratoanchusochan(n)) {
		printf("So da cho toan chu so chan");
	}
	else {
		printf("So da cho KHONG toan chu so chan");
	}
	return 0;
}