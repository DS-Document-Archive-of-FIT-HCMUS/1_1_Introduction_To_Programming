#include "Kiemtratoanchusochan.h"
bool Kiemtratoanchusochan(long n) {
	bool i = true;
	do {
		if ((n % 10) % 2 == 1) {
			i = false;
			break;
		}
		n = n - n % 10;
		n = n / 10;
	} while (n != 0);
	return i;
}