#ifndef _Kiemtratoanchusochan_H_
#define _Kiemtratoanchusochan_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
bool Kiemtratoanchusochan(long n);

