#include "Header.h"
void nhapMang(int a[], int& n) {
	do {
		printf("Nhap so phan tu cua mang la: ");
		scanf_s("%d", &n);
		if (n < 0 || n >= MAX) {
			printf("Ban phai nhap lai! \n");
		}
	} while (n < 0 || n >= MAX);
	for (int i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf_s("%d", &a[i]);
	}
}
void xuatMang(int a[], int n) {
	printf("Mang la: \n");
	for (int i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	printf("\n");
}
//Bai140
int duongDauTien(int a[], int n) {
	int ddt = -1;
	for (int i = 0; i < n; i++) {
		if (a[i] > 0) {
			ddt = a[i];
			break;
		}
	}
	return ddt;
}
int duongNhoNhat(int a[], int n) {
	int dnn;
	if (duongDauTien(a, n) == -1) {
		return -1;
	}
	else {
		dnn = duongDauTien(a, n);
		for (int i = 0; i < n; i++) {
			if (a[i] < dnn) {
				dnn = a[i];
			}
		}
		return dnn;
	}
}
//Bai262
void chanTangLeTang(int a[], int n) {
	int i, j;
	for (i = 0; i < n - 1; i++) {
		for (j = i + 1; j < n; j++) {
			if (a[i] > a[j] && (a[i] % 2 - a[j] % 2) == 0) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
//Bai269
void sapXepTang(int a[], int n) {
	int i, j;
	for (i = 0; i < n - 1; i++) {
		for (j = i + 1; j < n; j++) {
			if (a[i] > a[j]) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
void themBaoToan(int a[], int& n, int x) {
	int k = 0;
	if (x >= a[n-1]) {
		k = n;
	}
	else {
		for (int i = 0; i < n; i++) {
			if (x >= a[i] && x <= a[i + 1]) {
				k = i + 1;
			}
		}
	}
	for (int i = n; i > k; i--) {
		a[i] = a[i - 1];
	}
	a[k] = x;
	n++;
}
