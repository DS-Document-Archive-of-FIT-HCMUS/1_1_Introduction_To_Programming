#ifndef _header_h_
#define _header_h_
#endif 
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;
#define MAX 100
void nhapMang(int a[], int& n);
void xuatMang(int a[], int n);
//Bai140
int duongDauTien(int a[], int n);
int duongNhoNhat(int a[], int n);
//Bai262
void chanTangLeTang(int a[], int n);
//Bai269
void sapXepTang(int a[], int n);
void themBaoToan(int a[], int& n, int x);

