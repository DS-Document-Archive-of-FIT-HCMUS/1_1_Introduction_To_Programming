#include "Header.h"
int main() {
	int a[MAX];
	int n;
	nhapMang(a, n);
	xuatMang(a, n);
	printf("\n");
	//Bai140
	printf("BAI 140:\n");
	printf("Theo de, gia tri duong nho nhat cua mang la: %d \n", duongNhoNhat(a, n));
	printf("\n");
	//Bai262
	printf("BAI 262:\n");
	chanTangLeTang(a, n);
	printf("Sau khi sap xep chan tang le tang ma khong thay doi vi tri tuong doi cua so chan va so le, ta co \n");
	xuatMang(a, n);
	printf("\n");
	//Bai269
	printf("BAI 269:\n");
	sapXepTang(a, n);
	printf("Sau khi sap xep tang dan, ta co \n");
	xuatMang(a, n);
	int x;
	printf("Nhap x=");
	scanf_s("%d", &x);
	themBaoToan(a, n, x);
	printf("Theo de, sau khi them x vao, ta co \n");
	xuatMang(a, n);
	return 0;
}