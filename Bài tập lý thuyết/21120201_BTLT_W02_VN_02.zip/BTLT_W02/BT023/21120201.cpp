#include <stdio.h>
int main()
{
	long soxe, sonut, dv, c, t, n, v; 
	printf("Nhap bien so xe gom 5 chu so cua ban: ");
	scanf_s("%ld", &soxe);
	dv = soxe % 10;
	c = ((soxe - dv) / 10) % 10;
	t = ((soxe - dv - c * 10) / 100) % 10; 
	n = ((soxe - dv - c * 10 - t * 100) / 1000) % 10; 
	v = ((soxe - dv - c * 10 - t * 100 - n * 1000) / 10000) % 10; 
	sonut = dv + c + t + n + v; 
	printf("So xe cua ban duoc %ld nut", sonut);
	return 0;
}
