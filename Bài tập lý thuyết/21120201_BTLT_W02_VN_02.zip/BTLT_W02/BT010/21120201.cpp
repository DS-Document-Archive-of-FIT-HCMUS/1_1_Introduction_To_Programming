#include <stdio.h>
int main()
{
	float bankinh, chuvi, dientich;
	const float pi = 3.14;
	printf("Nhap ban kinh duong tron: ");
	scanf_s("%f", &bankinh);
	printf("\n");
	chuvi = 2 * pi * bankinh;
	dientich = pi * bankinh * bankinh;
	printf("Chu vi hinh tron la : % f \n", chuvi);
	printf("Dien tich hinh tron la : % f", dientich);
	return 0;
}