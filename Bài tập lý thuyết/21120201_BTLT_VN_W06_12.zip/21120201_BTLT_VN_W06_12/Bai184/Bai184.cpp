#include "Bai184.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%d", &a[i]);
	}
}
bool kiemTraNguyenTo(int x) {
	bool k = true;
	if (x == 0 || x == 1) {
		k = false;
	}
	else {
		for (int i = 2; i < x; i++) {
			if (x % i == 0) {
				k = false;
				break;
			}
		}
	}
	return k;
}
void lietKeViTriNguyenTo(int a[], int n) {
	printf("Vi tri cac phan tu nguyen to cua mang la: \n");
	for (int i = 0; i < n; i++) {
		if (kiemTraNguyenTo(a[i]) == true) {
			printf("%d ", i);
		}
	}
}