#include "Bai184.h"
int main() {
	int a[MAX];
	int n = 0;
	nhapMang(a, n);
	lietKeViTriNguyenTo(a, n);
	return 0;
}