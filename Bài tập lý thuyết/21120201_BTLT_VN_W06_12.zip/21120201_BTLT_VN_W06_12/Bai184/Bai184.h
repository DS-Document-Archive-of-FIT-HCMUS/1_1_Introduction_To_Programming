#ifndef _BAI184_H_
#define _BAI184_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(int a[], int& n);
bool kiemTraNguyenTo(int x);
void lietKeViTriNguyenTo(int a[], int n);
