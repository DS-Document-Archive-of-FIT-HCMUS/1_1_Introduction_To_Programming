#include "Bai183.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
double maxCuaMang(double a[], int n) {
	double Max=a[0];
	for (int i = 1; i < n; i++) {
		if (a[i] > Max) {
			Max = a[i];
		}
	}
	return Max;
}
void lietKeViTriLonNhat(double a[], int n) {
	printf("Cac vi tri cua gia tri lon nhat cua mang la: \n");
	for (int i = 0; i < n; i++) {
		if (a[i] == maxCuaMang(a, n)) {
			printf("%d ", i);
		}
	}
}