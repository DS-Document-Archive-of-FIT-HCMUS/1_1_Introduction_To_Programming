#ifndef _BAI183_H_
#define _BAI183_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(double a[], int& n);
double maxCuaMang(double a[], int n);
void lietKeViTriLonNhat(double a[], int n);