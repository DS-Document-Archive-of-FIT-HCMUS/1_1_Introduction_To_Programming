#include "Bai183.h"
int main() {
	double a[MAX];
	int n = 0;
	nhapMang(a, n);
	lietKeViTriLonNhat(a, n);
	return 0;
}