#include "Bai187.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
double duongDauTienCuaMang(double a[], int n) {
	double d = 0;
	for (int i = 0; i < n; i++) {
		if (a[i] > 0) {
			d = a[i];
			break;
		}
	}
	return d;
}
double giaTriDuongNhoNhatCuaMang(double a[], int n) {
	double dMin = 0;
	if (duongDauTienCuaMang(a, n) == 0) {
		return 0;
	}
	else {
		dMin = duongDauTienCuaMang(a, n);
		for (int i = 0; i < n; i++) {
			if (a[i] > dMin) {
				dMin = a[i];
			}
		}
		return dMin;
	}
}
void lietKeViTriBangGiaTriDuongNhoNhat(double a[], int n) {
	printf("Cac vi tri bang gia tri duong nho nhat cua mang la: \n");
	if (giaTriDuongNhoNhatCuaMang(a, n) == 0) {
		printf("Mang KHONG co gia tri duong\n");
	}
	else {
		for (int i = 0; i < n; i++) {
			if (a[i] == giaTriDuongNhoNhatCuaMang(a, n)) {
				printf("%d ", i);
			}
		}
	}
}