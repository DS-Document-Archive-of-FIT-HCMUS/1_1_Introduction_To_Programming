#ifndef _BAI176_H_
#define _BAI176_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(float a[], int& n);
void lietkesoam(float a[], int n);