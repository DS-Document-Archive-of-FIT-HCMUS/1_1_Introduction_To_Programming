#include "bai176.h"
void nhapMang(float a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%f", &a[i]);
	}
}
void lietkesoam(float a[], int n) {
	printf("Cac phan tu am cua mang la: \n");
	for (int i = 0; i < n; i++) {
		if (a[i] < 0) {
			printf("%0.2f ", a[i]);
		}
	}
}
