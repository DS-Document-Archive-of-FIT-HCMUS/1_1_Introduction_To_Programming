#include "bai176.h"
int main() {
	float a[MAX];
	int n = 0;
	nhapMang(a, n);
	lietkesoam(a, n);
	return 0;
}