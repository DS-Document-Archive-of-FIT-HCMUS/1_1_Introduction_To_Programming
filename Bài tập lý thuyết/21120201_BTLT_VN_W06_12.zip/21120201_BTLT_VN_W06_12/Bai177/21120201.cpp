#include "Bai177.h"
int main() {
	double a[MAX];
	int n = 0;
	nhapMang(a, n);
	double x, y;
	printf("Nhap x, y theo thu tu (x<y) la: \n");
	scanf_s("%lf %lf", &x, &y);
	lietKeSoThuocDoanXY(a, n, x, y);
	return 0;
}