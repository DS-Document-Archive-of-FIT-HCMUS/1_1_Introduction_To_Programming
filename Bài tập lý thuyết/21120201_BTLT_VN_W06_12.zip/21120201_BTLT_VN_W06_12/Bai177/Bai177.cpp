#include "Bai177.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
void lietKeSoThuocDoanXY(double a[], int n, double x, double y) {
	printf("Cac phan tu thuoc doan [%lf;%lf] cua mang la: \n", x, y);
	for (int i = 0; i < n; i++) {
		if (a[i] >= x && a[i] <= y) {
			printf("%0.2lf ", a[i]);
		}
	}
}