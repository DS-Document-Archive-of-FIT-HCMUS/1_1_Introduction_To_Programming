#ifndef _BAI188_H_
#define _BAI188_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(int a[], int& n);
int giaTriChanDauTien(int a[], int n);
int giaTriChanLonNhat(int a[], int n);
void lietKeViTriChanLonNhat(int a[], int n);
