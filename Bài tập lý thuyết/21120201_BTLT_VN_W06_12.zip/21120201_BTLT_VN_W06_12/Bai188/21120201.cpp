#include "Bai188.h"
int main() {
	int a[MAX];
	int n = 0;
	nhapMang(a, n);
	lietKeViTriChanLonNhat(a, n);

	return 0;
}