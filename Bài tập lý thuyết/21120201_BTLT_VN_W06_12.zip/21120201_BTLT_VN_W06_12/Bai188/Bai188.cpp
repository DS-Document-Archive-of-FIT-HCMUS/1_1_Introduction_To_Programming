#include "Bai188.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%d", &a[i]);
	}
}
int giaTriChanDauTien(int a[], int n) {
	int c = 1;
	for (int i = 0; i < n; i++) {
		if (a[i] % 2 == 0) {
			c = a[i];
			break;
		}
	}
	return c;
}
int giaTriChanLonNhat(int a[], int n) {
	int cmax;
	if (giaTriChanDauTien(a, n) == 1) {
		return 1;
	}
	else {
		cmax = giaTriChanDauTien(a, n);
		for (int i = 0; i < n; i++) {
			if (a[i] % 2 == 0 && a[i] > cmax) {
				cmax = a[i];
			}
		}
		return cmax;
	}
}
void lietKeViTriChanLonNhat(int a[], int n) {
	cout << "Cac vi tri chan lon nhat cua mang la: \n";
	if (giaTriChanLonNhat(a, n) == 1) {
		cout << "Mang KHONG co gia tri chan!";
	}
	else {
		for (int i = 0; i < n; i++) {
			if (a[i] == giaTriChanLonNhat(a, n)) {
				cout << i << " ";
			}
		}
	}
}