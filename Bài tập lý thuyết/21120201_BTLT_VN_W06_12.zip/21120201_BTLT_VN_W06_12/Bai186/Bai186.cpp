#include "Bai186.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
double giaTriAmDauTienCuaMang(double a[], int n) {
	double d = 0; 
	for (int i = 0; i < n; i++) {
		if (a[i] < 0) {
			d = a[i];
			break;
		}
	}
	return d;
}
void lietKeViTriBangGiaTriAmDauTien(double a[], int n) {
	printf("Cac vi tri bang gia tri am dau tien cua mang la: \n");
	if (giaTriAmDauTienCuaMang(a, n) == 0) {
		printf("Mang nay KHONG co gia tri am!");
	}
	else {
		for (int i = 0; i < n; i++) {
			if (a[i] == giaTriAmDauTienCuaMang(a, n)) {
				printf("%d ", i);
			}
		}
	}
}