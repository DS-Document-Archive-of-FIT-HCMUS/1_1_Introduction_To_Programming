#include "Bai186.h"
int main() {
	double a[MAX];
	int n = 0;
	nhapMang(a, n);
	lietKeViTriBangGiaTriAmDauTien(a, n);
	return 0;
}
