#ifndef _BAI186_H_
#define _BAI186_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(double a[], int& n);
double giaTriAmDauTienCuaMang(double a[], int n); 
void lietKeViTriBangGiaTriAmDauTien(double a[], int n);