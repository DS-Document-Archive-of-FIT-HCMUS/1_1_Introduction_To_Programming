#include "Bai180.h"
int main() {
	double a[MAX];
	int n = 0;
	nhapMang(a, n);
	kiemTraPhanTuNhoHonABSLienSauVaLonHonGTLienTruocNo(a, n);
	return 0;
}