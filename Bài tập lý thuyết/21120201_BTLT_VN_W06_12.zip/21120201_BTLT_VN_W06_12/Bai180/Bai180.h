#ifndef _BAI180_H_
#define _BAI180_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(double a[], int& n);
void kiemTraPhanTuNhoHonABSLienSauVaLonHonGTLienTruocNo(double a[], int n);
