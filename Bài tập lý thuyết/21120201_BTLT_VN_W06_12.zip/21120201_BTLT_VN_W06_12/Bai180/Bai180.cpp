#include "Bai180.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
void kiemTraPhanTuNhoHonABSLienSauVaLonHonGTLienTruocNo(double a[], int n) {
	printf("Cac phan tu nho hon tri tuyet doi cua gia tri dung lien sau no va lon hon gia tri dung lien truoc no la \n");
	for (int i = 1; i < n - 1; i++) {
		if (a[i] < abs(a[i + 1]) && a[i]>a[i - 1]) {
			printf("a[%d] = %lf\n", i, a[i]);
		}
	}
}