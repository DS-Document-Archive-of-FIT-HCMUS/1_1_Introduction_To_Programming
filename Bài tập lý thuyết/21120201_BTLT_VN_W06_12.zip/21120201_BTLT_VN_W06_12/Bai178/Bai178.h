#ifndef _BAI178_H_
#define _BAI178_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(int a[], int& n);
void lietKeSoChanThuocDoanXY(int a[], int n, int x, int y);