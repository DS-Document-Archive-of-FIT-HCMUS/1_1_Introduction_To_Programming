#include "Bai178.h"
int main() {
	int a[MAX];
	int n = 0;
	nhapMang(a, n);
	int x, y;
	printf("Nhap x, y theo thu tu (x<y) la: \n");
	scanf_s("%d %d", &x, &y);
	lietKeSoChanThuocDoanXY(a, n, x, y);
	return 0;
}