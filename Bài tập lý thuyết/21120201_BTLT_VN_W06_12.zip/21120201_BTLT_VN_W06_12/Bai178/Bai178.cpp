#include "Bai178.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%d", &a[i]);
	}
}
void lietKeSoChanThuocDoanXY(int a[], int n, int x, int y) {
	printf("Cac so chan thuoc doan [%d;%d] cua mang la: \n", x, y);
	for (int i = 0; i <= n; i++) {
		if (a[i] >= x && a[i] <= y && a[i] % 2 == 0) {
			printf("%d ", a[i]);
		}
	}
} 