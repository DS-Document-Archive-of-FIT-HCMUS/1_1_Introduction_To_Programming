#include "Bai181.h"
int main() {
	int a[MAX];
	int n = 0;
	nhapMang(a, n);
	kiemTraCoLanCanLaChan(a, n);
	return 0;
}