#include "Bai181.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%d", &a[i]);
	}
}
void kiemTraCoLanCanLaChan(int a[], int n) {
	printf("Cac phan tu co it nhat mot lan can la chan la: \n");
	if (a[1] % 2 == 0) {
		printf("a[1] = %d\n", a[1]);
	}
	for (int i = 1; i < n - 1; i++) {
		if (a[i - 1] % 2 == 0 || a[i + 1] % 2 == 0) {
			printf("a[%d] = %d\n", i, a[i]);
		}
	}
	if (a[n - 2] % 2 == 0) {
		printf("a[%d] = %d\n", n - 1, a[n - 1]);
	}
}