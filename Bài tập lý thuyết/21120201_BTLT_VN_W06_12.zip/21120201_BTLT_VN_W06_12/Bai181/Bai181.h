#ifndef _BAI181_H_
#define _BAI181_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(int a[], int& n);
void kiemTraCoLanCanLaChan(int a[], int n);