#ifndef _BAI184_H_
#define _BAI184_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(int a[], int& n);
bool kiemTraSoChinhPhuong(int x);
void lietKeViTriSoChinhPhuong(int a[], int n);
