#include "Bai185.h"
void nhapMang(int a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%d", &a[i]);
	}
}
bool kiemTraSoChinhPhuong(int x) {
	bool k;
	if ((int)sqrt(x) - sqrt(x) == 0) {
		k = true;
	}
	else {
		k = false;
	}
	return k;
}
void lietKeViTriSoChinhPhuong(int a[], int n) {
	printf("Cac vi tri cua phan tu so chinh phuong cua mang la: \n");
	for (int i = 0; i < n; i++) {
		if (kiemTraSoChinhPhuong(a[i]) == true) {
			printf("%d ", a[i]); 
		}
	}
}