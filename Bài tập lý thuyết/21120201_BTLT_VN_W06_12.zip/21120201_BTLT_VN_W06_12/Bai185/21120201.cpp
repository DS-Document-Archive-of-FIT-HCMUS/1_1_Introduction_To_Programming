#include "Bai185.h"
int main() {
	int a[MAX];
	int n = 0;
	nhapMang(a, n);
	lietKeViTriSoChinhPhuong(a, n);
	return 0;
}