#include "Bai179.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
void kiemTraPhanTuLonHonABSLienSauNo(double a[], int n) {
	printf("Cac phan tu lon hon gia tri tuyet doi cua gia tri lien truoc no: \n");
	for (int i = 0; i < n - 1; i++) {
		if (a[i] > abs(a[i + 1])) {
			printf("a[%d] = %lf\n", i, a[i]);
		}
	}
}