#include "Bai179.h"
int main() {
	double a[MAX];
	int n = 0;
	nhapMang(a, n);
	kiemTraPhanTuLonHonABSLienSauNo(a, n);
	return 0;
}