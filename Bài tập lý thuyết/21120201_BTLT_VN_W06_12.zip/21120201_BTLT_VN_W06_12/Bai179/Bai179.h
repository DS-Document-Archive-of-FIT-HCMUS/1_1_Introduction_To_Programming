#ifndef _BAI179_H_
#define _BAI179_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(double a[], int& n);
void kiemTraPhanTuLonHonABSLienSauNo(double a[], int n);
