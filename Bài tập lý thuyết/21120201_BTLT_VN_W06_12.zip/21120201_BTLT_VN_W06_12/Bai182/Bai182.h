#ifndef _BAI182_H_
#define _BAI182_H_
#endif

#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <iostream>

using namespace std;

#define MAX 100

void nhapMang(double a[], int& n);
void kiemTraLanCanTraiDau(double a[], int n);
