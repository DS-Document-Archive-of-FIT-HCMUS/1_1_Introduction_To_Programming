#include "Bai182.h"
int main() {
	double a[MAX];
	int n = 0;
	nhapMang(a, n);
	kiemTraLanCanTraiDau(a, n);
	return 0;
}