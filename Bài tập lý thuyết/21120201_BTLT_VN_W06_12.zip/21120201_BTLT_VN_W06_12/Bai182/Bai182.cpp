#include "Bai182.h"
void nhapMang(double a[], int& n) {
	printf("Nhap so phan tu cua mang n = ");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%lf", &a[i]);
	}
}
void kiemTraLanCanTraiDau(double a[], int n) {
	printf("Cac phan tu co it nhat mot lan can trai dau la: \n");
	if (a[0] * a[1] < 0) {
		printf("a[0]=%lf\n", a[0]);
	}
	for (int i = 1; i < n - 1; i++) {
		if (a[i - 1] * a[i] < 0 || a[i] * a[i + 1] < 0) {
			printf("a[%d]=%lf\n", i, a[i]);
		}
	}
	if (a[n - 1] * a[n - 2] < 0) {
		printf("a[%d]=%lf\n", n - 1, a[n - 1]);
	}
}