#include "IntArray.h"

void nhapMang(float a[], int &n) {
	printf("Nhap n=");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Nhap a[%d]=", i);
		scanf_s("%f", &a[i]);
	}
}

void xuatMang(float a[], int n) {
	printf("Mang la: \n");
	for (int i = 0; i < n; i++) {
		printf("%f ", a[i]);
	}
}