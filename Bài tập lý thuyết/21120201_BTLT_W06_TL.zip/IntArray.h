#ifndef _INTARRAY_H_
#define _INTARRAY_H_
#endif

#include <stdio.h>
#include <iostream>

using namespace std;

void nhapMang(float a[], int &n);
void xuatMang(float a[], int n);

