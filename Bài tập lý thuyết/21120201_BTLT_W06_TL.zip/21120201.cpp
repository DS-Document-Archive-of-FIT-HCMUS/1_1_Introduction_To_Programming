#include "IntArray.h"

int main() {
	float a[100];
	int n = 0;
	nhapMang(a, n);
	xuatMang(a, n);
	return 0;
}