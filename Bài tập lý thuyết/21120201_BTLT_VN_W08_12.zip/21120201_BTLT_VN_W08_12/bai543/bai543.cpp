#include "bai543.h"
void inputPoint(point2D& p) {
	printf("Nhap hoanh do cua diem la: ");
	scanf_s("%lf", &p.x);
	printf("Nhap tung do cua diem la: ");
	scanf_s("%lf", &p.y);
}
void outputPoint(point2D p) {
	printf("(%0.3lf,%0.3lf)\n", p.x, p.y);
}
double khoangCach(point2D p1, point2D p2) {
	return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
