#include "bai543.h"
int main() {
	point2D pointA, pointB;
	printf("Nhap toa do diem A:\n");
	inputPoint(pointA);
	printf("Nhap toa do diem B:\n");
	inputPoint(pointB);
	printf("Toa do diem A:\n");
	outputPoint(pointA);
	printf("Toa do diem B:\n");
	outputPoint(pointB);
	printf("Khoang cach giua 2 diem la: %0.3lf", khoangCach(pointA, pointB));
	return 0;
}