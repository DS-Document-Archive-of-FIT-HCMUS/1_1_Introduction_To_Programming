#include "bai1002.h"
int main() {
	cacTamGiac tamgiac[MAX];
	int n;
	nhapMangTamGiac(tamgiac, n);
	timTamGiacCoChuViLonNhat(tamgiac, n);
	return 0;
}