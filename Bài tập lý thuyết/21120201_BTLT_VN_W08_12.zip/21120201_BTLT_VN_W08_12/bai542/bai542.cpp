#include "bai542.h"
void inputPoint(point2D& p) {
	printf("Nhap hoanh do cua diem la: ");
	scanf_s("%lf", &p.x);
	printf("Nhap tung do cua diem la: ");
	scanf_s("%lf", &p.y);
}
void outputPoint(point2D p) {
	printf("(%0.3lf,%0.3lf)", p.x, p.y);
}
