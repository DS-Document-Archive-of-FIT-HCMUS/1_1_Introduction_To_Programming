#include "bai542.h"
int main() {
	point2D pointA;
	inputPoint(pointA);
	outputPoint(pointA);
	return 0;
}