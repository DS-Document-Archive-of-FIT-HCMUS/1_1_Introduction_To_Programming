#include "bai584.h"
int main() {
	cacTamGiac tamgiac;
	inputTriangle(tamgiac);
	xuatTamGiac(tamgiac);
	if (kiemTraTamGiac(tamgiac)) {
		printf("La 3 canh cua tam giac!\n");
	}
	else {
		printf("KHONG la 3 canh cua tam giac!\n");
	}
	return 0;
}