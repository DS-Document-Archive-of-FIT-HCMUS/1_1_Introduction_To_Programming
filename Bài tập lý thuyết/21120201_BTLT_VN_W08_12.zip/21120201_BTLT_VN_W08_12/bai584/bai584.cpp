#include "bai584.h"
void inputPoint(point2D& p) {
	printf("Nhap hoanh do cua diem la: ");
	scanf_s("%lf", &p.x);
	printf("Nhap tung do cua diem la: ");
	scanf_s("%lf", &p.y);
}
void inputTriangle(cacTamGiac& tamgiac) {
	printf("Nhap toa do dinh thu nhat \n");
	inputPoint(tamgiac.dinh1);
	printf("Nhap toa do dinh thu hai \n");
	inputPoint(tamgiac.dinh2);
	printf("Nhap toa do dinh thu ba \n");
	inputPoint(tamgiac.dinh3);
}
void xuatTamGiac(cacTamGiac tamgiac) {
	printf("((%0.3lf,%0.3lf);(%0.3lf,%0.3lf);(%0.3lf,%0.3lf))\n", tamgiac.dinh1.x, tamgiac.dinh1.y, tamgiac.dinh2.x, tamgiac.dinh2.y, tamgiac.dinh3.x, tamgiac.dinh3.y);
}
double doDaiCanh(point2D p1, point2D p2) {
	return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
bool kiemTraTamGiac(cacTamGiac tamgiac) {
	double d1 = doDaiCanh(tamgiac.dinh1, tamgiac.dinh2),
		d2 = doDaiCanh(tamgiac.dinh2, tamgiac.dinh3),
		d3 = doDaiCanh(tamgiac.dinh3, tamgiac.dinh1);
	if ((d1 + d2) > d3 && d3 > abs(d1 - d2) && d1 > 0 && d2 > 0 && d3 > 0) {
		return 1;
	}
	else {
		return 0;
	}
}