#ifndef _BAI584_H_
#define _BAI584_H_
#endif
#include <stdio.h>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <cstring>
#include <string.h>
#define MAX 100
struct point2D {
	double x;
	double y;
};
struct cacTamGiac {
	point2D dinh1;
	point2D dinh2;
	point2D dinh3;
};
void inputPoint(point2D& p);
void inputTriangle(cacTamGiac& tamgiac);
void xuatTamGiac(cacTamGiac tamgiac);
bool kiemTraTamGiac(cacTamGiac tamgiac);