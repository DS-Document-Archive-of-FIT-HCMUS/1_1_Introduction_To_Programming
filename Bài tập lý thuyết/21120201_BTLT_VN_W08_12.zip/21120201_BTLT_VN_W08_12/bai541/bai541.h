#ifndef _BAI541_H_
#define _BAI541_H_
#endif 
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <string.h>
#include <cstring>
using namespace std;
#define MAX 100
struct point2D {
	double x;
	double y;
};
void inputPoint(point2D& p);