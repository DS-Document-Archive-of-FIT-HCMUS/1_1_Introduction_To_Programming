#include "bai541.h"
void inputPoint(point2D& p) {
	printf("Nhap hoanh do cua diem la: ");
	scanf_s("%lf", &p.x);
	printf("Nhap tung do cua diem la: ");
	scanf_s("%lf", &p.y);
}

