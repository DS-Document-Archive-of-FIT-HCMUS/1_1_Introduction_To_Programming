#include "bai541.h"
int main() {
	point2D pointA;
	inputPoint(pointA);
	return 0;
}