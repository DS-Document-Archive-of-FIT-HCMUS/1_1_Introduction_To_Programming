#include "bai585.h"
int main() {
	cacTamGiac tamgiac;
	inputTriangle(tamgiac);
	xuatTamGiac(tamgiac);
	if (kiemTraTamGiac(tamgiac)) {
		printf("La 3 canh cua tam giac!\n");
		printf("Chu vi tam giac la: %lf", chuViTamGiac(tamgiac));
	}
	else {
		printf("KHONG la 3 canh cua tam giac!\n");
	}
	return 0;
}