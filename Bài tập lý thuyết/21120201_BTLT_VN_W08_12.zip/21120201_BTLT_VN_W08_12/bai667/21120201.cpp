#include "bai667.h"
int main() {
	cacTinh Tinh[MAX]; 
	int n;
	nhapTinh(Tinh, n);
	//Cau a
	printf("\n");
	dsTinhLonHon1M(Tinh, n);
	printf("\n");
	//Cau b
	printf("Mot tinh co dien tich lon nhat la: ");
	printf(STinhMax(Tinh, n).tenTinh);
	printf("\n\n");
	//Cau c
	sapXepGiamS(Tinh, n);
	printf("Mang cac tinh sau khi da sap xep dien tich giam dan la\n");
	xuatTinh(Tinh, n);
	return 0;
}