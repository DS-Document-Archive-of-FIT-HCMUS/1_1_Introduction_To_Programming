#ifndef _BAI667_H_
#define _BAI667_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <cstring>
#include <string.h>
using namespace std;
#define MAX 100
struct cacTinh {
	int maTinh;
	char tenTinh[31];
	int danSo;
	double dienTich;
};
void nhap1Tinh(cacTinh& t);
void nhapTinh(cacTinh t[], int& n);
void xuat1Tinh(cacTinh t);
void xuatTinh(cacTinh t[], int n);
//Cau a
void dsTinhLonHon1M(cacTinh t[], int n);
//Cau b
cacTinh STinhMax(cacTinh t[], int n);
//Cau c
void sapXepGiamS(cacTinh t[], int n);