#include "bai667.h"
void nhap1Tinh(cacTinh& t) {
	printf("Nhap ma tinh: ");
	scanf_s("%d", &t.maTinh);
	printf("Nhap ten tinh: ");
	cin.ignore();
	cin.getline(t.tenTinh, 31);
	printf("Nhap dan so: ");
	scanf_s("%d", &t.danSo);
	printf("Nhap dien tich: ");
	scanf_s("%lf", &t.dienTich);
}
void nhapTinh(cacTinh t[], int& n) {
	do {
		printf("So tinh can nhap la: ");
		scanf_s("%d", &n);
		if (n < 0 || n>63) {
			printf("Ban phai nhap lai!\n");
		}
	} while (n < 0 || n>63);
	for (int i = 0; i < n; i++) {
		printf("Nhap thong tin tinh thu %d\n", i + 1);
		nhap1Tinh(t[i]);
	}
}
void xuat1Tinh(cacTinh t) {
	printf("%d - %s - %d - %lf \n", t.maTinh, t.tenTinh, t.danSo, t.dienTich);
}
void xuatTinh(cacTinh t[], int n) {
	for (int i = 0; i < n; i++) {
		printf("Tinh thu %d la:\n", i + 1);
		xuat1Tinh(t[i]);
	}
}
//Cau a
void dsTinhLonHon1M(cacTinh t[], int n) {
	printf("Cac tinh co dan so lon hon 1.000.000 la: \n");
	for (int i = 0; i < n; i++) {
		if (t[i].danSo > 1000000) {
			xuat1Tinh(t[i]);
		}
	}
}
//Cau b
cacTinh STinhMax(cacTinh t[], int n) {
	cacTinh s = t[0];
	double Smax = t[0].dienTich;
	for (int i = 1; i < n; i++) {
		if (t[i].dienTich > Smax) {
			Smax = t[i].dienTich;
			s = t[i];
		}
	}
	return s;
}
//Cau c
void sapXepGiamS(cacTinh t[], int n) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n; j++) {
			if (t[i].dienTich < t[j].dienTich) {
				cacTinh temp = t[i];
				t[i] = t[j];
				t[j] = temp;
			}
		}
	}
}
