#include "bai540.h"
int main() {

	return 0;
}