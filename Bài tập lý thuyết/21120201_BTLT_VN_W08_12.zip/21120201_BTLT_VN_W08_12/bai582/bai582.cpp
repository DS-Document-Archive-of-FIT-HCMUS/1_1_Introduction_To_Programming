#include "bai582.h"
void inputPoint(point2D &p) {
	printf("Nhap hoanh do cua diem la: ");
	scanf_s("%lf", &p.x);
	printf("Nhap tung do cua diem la: ");
	scanf_s("%lf", &p.y);
}
void inputTriangle(cacTamGiac &tamgiac) {
	printf("Nhap toa do dinh thu nhat \n");
	inputPoint(tamgiac.dinh1);
	printf("Nhap toa do dinh thu hai \n");
	inputPoint(tamgiac.dinh2);
	printf("Nhap toa do dinh thu ba \n");
	inputPoint(tamgiac.dinh3);
}

