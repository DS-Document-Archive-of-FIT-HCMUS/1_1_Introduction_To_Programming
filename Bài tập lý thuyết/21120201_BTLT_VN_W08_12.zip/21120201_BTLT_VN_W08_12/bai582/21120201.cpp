#include "bai582.h"
int main() {
	cacTamGiac tamgiac; 
	inputTriangle(tamgiac);
	return 0;
}