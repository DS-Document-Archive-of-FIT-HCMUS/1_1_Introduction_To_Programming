#include "bai581.h"
int main() {
	return 0;
}