#include "bai583.h"
void inputPoint(point2D& p) {
	printf("Nhap hoanh do cua diem la: ");
	scanf_s("%lf", &p.x);
	printf("Nhap tung do cua diem la: ");
	scanf_s("%lf", &p.y);
}
void inputTriangle(cacTamGiac& tamgiac) {
	printf("Nhap toa do dinh thu nhat \n");
	inputPoint(tamgiac.dinh1);
	printf("Nhap toa do dinh thu hai \n");
	inputPoint(tamgiac.dinh2);
	printf("Nhap toa do dinh thu ba \n");
	inputPoint(tamgiac.dinh3);
}
void xuatTamGiac(cacTamGiac tamgiac) {
	printf("((%0.3lf,%0.3lf);(%0.3lf,%0.3lf);(%0.3lf,%0.3lf))\n", tamgiac.dinh1.x, tamgiac.dinh1.y, tamgiac.dinh2.x, tamgiac.dinh2.y, tamgiac.dinh3.x, tamgiac.dinh3.y);
}
double doDaiCanh(point2D p1, point2D p2) {
	return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
