#include "bai583.h"
int main() {
	cacTamGiac tamgiac;
	inputTriangle(tamgiac);
	xuatTamGiac(tamgiac);
	return 0;
}