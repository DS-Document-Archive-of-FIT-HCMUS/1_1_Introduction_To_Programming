#include "bai1001.h"
int main() {
	cacTamGiac tamgiac[MAX];
	int n;
	nhapMangTamGiac(tamgiac, n);
	return 0;
}