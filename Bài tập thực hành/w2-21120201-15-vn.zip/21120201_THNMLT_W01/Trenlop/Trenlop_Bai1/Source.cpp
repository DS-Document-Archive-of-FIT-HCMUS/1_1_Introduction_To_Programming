#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {

	cout << "1. In C, lowercase letters are significant." << endl;
	cout << "2. main is where program execution begins." << endl;
	cout << "3. Opening and closing braces enclose program statements in a routine." << endl;
	cout << "4. All program statements must be terminated by a semicolon.";

	return 0;
}