#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float a;
    //INPUT
    cout << "Nhap vao chieu dai canh hinh vuong la: ";
    cin >> a;
    //OUTPUT
    cout << "Chu vi cua hinh vuong la: " << 4 * a << endl;
    cout << "Dien tich cua hinh vuong la: " << a * a << endl;
    return 0;
}