#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float x;
    //INPUT
    cout << "Nhap x=";
    cin >> x;
    //OUTPUT
    cout << "Gia tri cua A = ";
    cout << fixed << setprecision(2) << 3 * x * x * x - 2 * x * x;
    return 0;
}