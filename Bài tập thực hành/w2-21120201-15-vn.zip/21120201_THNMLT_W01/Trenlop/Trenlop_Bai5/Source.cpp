#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float a, b;
    //INPUT
    cout << "Nhap chieu dai 2 canh cua hinh chu nhat theo thu tu la: ";
    cin >> a >> b;
    //OUTPUT
    cout << "Chu vi cua hinh chu nhat la: " << (a + b) * 2 << endl;
    cout << "Dien tich cua hinh chu nhat la: " << a * b;
    return 0;
}