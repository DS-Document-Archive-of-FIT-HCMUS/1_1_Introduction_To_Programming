#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    char x;
    //INPUT
    cout << "Nhap vao ky tu x la: ";
    cin >> x;
    cout << "Ky tu x la: " << x << endl;
    cout << "Ma ASCII tuong ung la: " << (int)x;
    return 0;
}