#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
	int a, b;
	//INPUT
	cout << "Nhap a=";
	cin >> a;
	cout << "Nhap b=";
	cin >> b;
	//OUTPUT
	cout << "Tong 2 so la: " << a + b << endl;
	cout << "Hieu 2 so la: " << a - b << endl;
	cout << "Tich 2 so la: " << a * b << endl;
	cout << "Thuong 2 so la:" << (float)(1.0 * a / b);
	return 0;
}