#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float cv;
    //INPUT
    cout << "Chu vi cua hinh chu nhat co chieu dai gap 1.5 lan chieu rong la: ";
    cin >> cv;
    //OUTPUT
    cout << "Dien tich cua hinh chu nhat do la: " << cv * cv / 25;
    return 0;
}