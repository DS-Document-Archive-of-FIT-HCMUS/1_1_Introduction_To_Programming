#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    unsigned int a, b;
    //INPUT
    cout << "Nhap vao gia tri nguyen duong a va b theo thu tu la: ";
    cin >> a >> b;
    //
    a = a ^ b;
    b = a ^ b;
    a = a ^ b;
    //OUTPUT
    cout << "Sau khi hoan doi, a = " << a << " va b = " << b;
    return 0;
}