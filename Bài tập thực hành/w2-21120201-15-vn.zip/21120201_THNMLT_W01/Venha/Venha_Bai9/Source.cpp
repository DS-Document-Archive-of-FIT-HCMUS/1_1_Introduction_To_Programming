#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    double M;
    unsigned int n;
    float q;
    //INPUT
    cout << "Nhap vao so tien gui: ";
    cin >> M;
    cout << "Nhap vao so thang gui: ";
    cin >> n;
    cout << "Nhap vao lai suat (be hon 1): ";
    cin >> q;
    //OUTPUT
    cout << "Tong so tien lai voi hinh thuc goi tiet kiem lai nhap von la: ";
    cout << M * pow(1 + q, n) - M;
    return 0;
}