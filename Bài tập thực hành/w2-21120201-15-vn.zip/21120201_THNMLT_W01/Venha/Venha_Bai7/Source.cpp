#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float dientich;
    const float pi = 3.14;
    //INPUT
    cout << "Dien tich hinh tron la: ";
    cin >> dientich;
    //OUTPUT
    cout << "Ban kinh hinh tron la: " << sqrt(dientich / pi);
    return 0;
}