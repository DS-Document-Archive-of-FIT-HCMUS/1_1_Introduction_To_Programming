#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float r, h;
    const float pi = 3.14;
    //INPUT
    cout << "Nhap ban kinh hinh tru la: ";
    cin >> r;
    cout << "Nhap chieu cao hinh tru la: ";
    cin >> h;
    //OUTPUT
    cout << "Dien tich be mat la: " << 2 * pi * r * (r + h) << endl;
    cout << "The tich la: " << pi * r * r * h;
    return 0;
}