#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    unsigned int a, b, c;
    //INPUT
    cout << "Nhap vao gia tri nguyen duong a, b, c theo thu tu la: ";
    cin >> a >> b >> c;
    //
    a = a + b + c;
    b = a - b - c;
    c = a - b - c;
    a = a - b - c;
    //OUTPUT
    cout << "Sau khi hoan doi:" << endl;
    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    cout << "c=" << c;
    return 0;
}