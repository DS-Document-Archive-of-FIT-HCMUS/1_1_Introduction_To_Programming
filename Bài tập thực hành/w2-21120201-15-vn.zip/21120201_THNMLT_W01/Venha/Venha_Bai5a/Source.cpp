#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float cc, cs, cr;
    //INPUT
    cout << "Chieu cao hinh hop chu nhat la: ";
    cin >> cc;
    cout << "Chieu sau hinh hop chu nhat la: ";
    cin >> cs;
    cout << "Chieu rong hinh hop chu nhat la:";
    cin >> cr;
    //OUTPUT
    cout << "Dien tich be mat la: " << 2 * (cc * cs + cs * cr + cr * cc) << endl;
    cout << "The tich la: " << cc * cs * cr;
    return 0;
}