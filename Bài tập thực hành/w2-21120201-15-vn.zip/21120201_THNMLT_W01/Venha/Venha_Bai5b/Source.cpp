#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float canh;
    //INPUT
    cout << "Nhap do dai canh hinh lap phuong la: ";
    cin >> canh;
    //OUTPUT
    cout << "Dien tich be mat la: " << 6 * canh * canh << endl;
    cout << "The tich la: " << canh * canh * canh;
    return 0;
}