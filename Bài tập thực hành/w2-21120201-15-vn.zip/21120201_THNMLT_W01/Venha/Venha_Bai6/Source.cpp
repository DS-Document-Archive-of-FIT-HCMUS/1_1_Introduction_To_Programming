#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    float a, r;
    const float pi = 3.14;
    //INPUT
    cout << "Nhap chieu dai canh tam giac deu la: ";
    cin >> a;
    cout << "Nhap ban kinh hinh tron la: "; // r<a
    cin >> r;
    //OUTPUT;
    cout << "Dien tich phan duoc to dam la: " << 3 * sqrt(3) * a * a / 4 + pi * r * r / 2;
    return 0;
}