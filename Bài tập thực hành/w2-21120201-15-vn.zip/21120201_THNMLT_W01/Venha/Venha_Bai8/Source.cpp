#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Nop bai W01_Ve nha
int main() {
    unsigned int n;
    float x;
    //INPUT
    cout << "Nhap so nguyen duong n = ";
    cin >> n;
    cout << "Nhap so thuc x = ";
    cin >> x;
    //OUTPUT
    cout << "Gia tri cua bieu thuc (x^2+1)^n = " << pow(x * x + 1, n);
    return 0;
}