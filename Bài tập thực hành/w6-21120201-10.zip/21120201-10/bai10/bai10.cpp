#include "bai10.h"
void nhapSoDuong(int& n) {
	do {
		cout << "Nhap so duong n=";
		cin >> n;
		if (n <= 0) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n <= 0);
}
int tinhF(int n) {
	int F0 = 1, F1 = 2;
	for (int i = 2; i <= n; i++) {
		int temp = F1;
		F1 = 3 * F1 - 2 * F0;
		F0 = temp;
	}
	return F1;
}