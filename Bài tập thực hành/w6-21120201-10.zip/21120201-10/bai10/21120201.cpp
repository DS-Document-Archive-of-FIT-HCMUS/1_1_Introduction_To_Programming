#include "bai10.h"
int main() {
	int n;
	nhapSoDuong(n);
	cout << "F(" << n << ")=" << tinhF(n);
	return 0;
}