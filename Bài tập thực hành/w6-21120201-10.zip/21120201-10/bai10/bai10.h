#ifndef _BAI10_H_
#define _BAI10_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
void nhapSoDuong(int& n);
int tinhF(int n);
