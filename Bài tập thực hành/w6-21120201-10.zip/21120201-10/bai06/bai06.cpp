#include "bai06.h"
void nhapSoDuong(int& n) {
	do {
		cin >> n;
		if (n <= 0) {
			cout << "Ban phai nhap lai gia tri = ";
		}
	} while (n <= 0);
}
int timUCLN(int a, int b) {
	int UCLN;
	for (int i = 1; i <= a && i <= b; i++) {
		if (a % i == 0 && b % i == 0) {
			UCLN = i;
		}
	}
	return UCLN;
}