#ifndef _BAI06_H_
#define _BAI06_H_
#endif 
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
void nhapSoDuong(int& n);
int timUCLN(int a, int b);