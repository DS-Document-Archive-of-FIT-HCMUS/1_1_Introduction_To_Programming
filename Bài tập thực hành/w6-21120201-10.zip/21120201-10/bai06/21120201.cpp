#include "bai06.h"
int main() {
	int a, b;
	cout << "Nhap so duong a=";
	nhapSoDuong(a);
	cout << "Nhap so duong b=";
	nhapSoDuong(b);
	cout << "Uoc chung lon nhat cua " << a << " va " << b << " la: " << timUCLN(a, b);
	return 0;
}