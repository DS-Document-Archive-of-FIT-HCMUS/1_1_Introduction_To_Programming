#include "bai09.h"
long chuyenNhiPhan(long n) {
	long bin = 0, n0 = abs(n);
	if (n == 0) {
		return 0;
	}
	else {
		int i = 0, dau = (int)(n / abs(n));
		while (n0 != 0) {
			bin = bin + ((n0 % 2) * pow(10, i));
			i++;
			n0 = (long)(n0 / 2);
		}
		return bin * dau;
	}
}