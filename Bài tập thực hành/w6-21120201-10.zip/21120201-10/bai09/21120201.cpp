#include "bai09.h"
int main() {
	long n;
	do {
		cout << "Nhap n=";
		cin >> n;
		if (n < -255 || n>255) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n < -255 || n>255);
	cout << n << " chuyen sang nhi phan la " << chuyenNhiPhan(n);
	return 0;
}