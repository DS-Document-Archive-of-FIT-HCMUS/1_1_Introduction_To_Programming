#ifndef _BAI07_H_
#define _BAI07_H_
#endif
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
using namespace std;
void nhapSoDuong(int& n);
int timBCNN(int a, int b);