#include "bai07.h"
void nhapSoDuong(int& n) {
	do {
		cin >> n;
		if (n <= 0) {
			cout << "Ban phai nhap lai gia tri la: ";
		}
	} while (n <= 0);
}
int timBCNN(int a, int b) {
	int BCNN;
	for (int i = a * b; i >= a && i >= b; i--) {
		if (i % a == 0 && i % b == 0) {
			BCNN = i;
		}
	}
	return BCNN;
}