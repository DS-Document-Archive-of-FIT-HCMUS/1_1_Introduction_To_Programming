#ifndef _BAI05_H_
#define _BAI05_H_
#endif 
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
using namespace std;
void demSoAm();