#include "bai05.h"
void demSoAm(){
	double k;
	int dem = 0;
	cout << "Nhap day so thuc: " << endl;
	do {
		cin >> k;
		if (k < 0) {
			dem++;
		}
	} while (k != 0);
	cout << "So so am trong day la: " << dem;
}