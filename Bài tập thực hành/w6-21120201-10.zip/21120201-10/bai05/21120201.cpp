#include "bai05.h"
int main() {
	demSoAm();
	return 0;
}