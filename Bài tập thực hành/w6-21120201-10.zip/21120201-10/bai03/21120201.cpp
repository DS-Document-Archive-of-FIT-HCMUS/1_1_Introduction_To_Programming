#include "Bai03.h"
int main() {
	long long n;
	nhapSoDuong(n);
	if (ktSoHoanHao(n)) {
		cout << n << " la so hoan hao";
	}
	else {
		cout << n << " KHONG la so hoan hao";
	}
	return 0;
}