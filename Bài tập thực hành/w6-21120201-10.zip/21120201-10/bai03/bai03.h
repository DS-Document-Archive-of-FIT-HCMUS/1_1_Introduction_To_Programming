#ifndef _BAI03_H_
#define _BAI03_H_
#endif 
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;
void nhapSoDuong(long long& n);
bool ktSoHoanHao(long long n);
