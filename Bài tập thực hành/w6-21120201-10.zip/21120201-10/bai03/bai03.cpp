#include "bai03.h"
void nhapSoDuong(long long& n) {
	do {
		cout << "Nhap so duong n=";
		cin >> n;
		if (n < 1 || n>100000000) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n < 1 || n>100000000);
}
bool ktSoHoanHao(long long n) {
	bool k = true;
	long long S = 0;
	for (int i = 1; i <= n; i++) {
		if (n % i == 0) {
			S = S + i;
		}
	}
	if (S != 2 * n) {
		k = false;
	}
	return k;
}