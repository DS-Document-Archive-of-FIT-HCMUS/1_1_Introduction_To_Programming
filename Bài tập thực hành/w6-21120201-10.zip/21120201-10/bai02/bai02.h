#ifndef _BAI02_H_
#define _BAI02_H_
#endif
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;
void nhapSoDuong(long long& n);
bool ktSoDoiXung(long long n);