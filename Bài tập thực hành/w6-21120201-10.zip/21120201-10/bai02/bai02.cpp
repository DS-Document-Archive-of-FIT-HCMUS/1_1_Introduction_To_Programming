#include "bai02.h"
void nhapSoDuong(long long& n) {
	do {
		cout << "Nhap so duong n=";
		cin >> n;
		if (n < 10 || n>10000000) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n < 10 || n>10000000);
}
bool ktSoDoiXung(long long n) {
	bool k = true;
	int S = 0;
	long long n0 = n;
	while (n != 0) {
		S = S * 10;
		S = S + n % 10;
		n = (n - n % 10) / 10;
	}
	if (S != n0) {
		k = false;
	}
	return k;
}