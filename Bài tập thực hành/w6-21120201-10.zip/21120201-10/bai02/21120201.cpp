#include "bai02.h"
int main() {
	long long n;
	nhapSoDuong(n);
	if (ktSoDoiXung(n)) {
		cout << n << " la so doi xung";
	}
	else {
		cout << n << " KHONG la so doi xung";
	}
	return 0;
}