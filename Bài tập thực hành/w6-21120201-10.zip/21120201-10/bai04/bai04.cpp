#include "bai04.h"
void nhapSoDuong(long long& n) {
	do {
		cout << "Nhap so duong n=";
		cin >> n;
		if (n <= 0) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n <= 0);
}
int timChuSoLonNhat(long long n) {
	int max = n % 10;
	while (n != 0) {
		n = (n - n % 10) / 10;
		if (n % 10 > max) {
			max = n % 10;
		}
	}
	return max;
}