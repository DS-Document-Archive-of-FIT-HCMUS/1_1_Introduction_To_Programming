#include "bai04.h"
int main() {
	long long n;
	nhapSoDuong(n);
	cout << "Chu so lon nhat cua so duong " << n << " la: " << timChuSoLonNhat(n);
	return 0;
}