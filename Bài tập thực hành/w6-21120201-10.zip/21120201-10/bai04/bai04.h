#ifndef _BAI04_H_
#define _BAI04_H_
#endif
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
void nhapSoDuong(long long& n);
int timChuSoLonNhat(long long n);
