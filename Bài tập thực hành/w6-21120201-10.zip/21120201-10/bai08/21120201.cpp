#include "bai08.h"
int main() {
	int a, b;
	cout << "Nhap a=";
	cin >> a;
	cout << "Nhap b=";
	cin >> b;
	hoanViSoNguyen(a, b);
	cout << "Sau khi hoan vi," << endl;
	cout << "a=" << a << endl;
	cout << "b=" << b;
	return 0;
}