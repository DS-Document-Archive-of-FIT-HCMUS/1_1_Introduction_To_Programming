#include "bai08.h"
void hoanViSoNguyen(int& a, int& b) {
	a = a + b;
	b = a - b;
	a = a - b;
}