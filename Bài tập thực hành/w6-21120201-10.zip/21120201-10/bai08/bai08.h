#ifndef _BAI08_H_
#define _BAI08_H_
#endif
#include <iostream>
#include <iomanip>
#include <math.h>
#include <stdio.h>
using namespace std;

void hoanViSoNguyen(int& a, int& b);