#include "bai01.h"
int main() {
	long long n;
	nhapSoDuong(n);
	if (ktSoHoanChinh(n)) {
		cout << n << " la so hoan chinh";
	}
	else {
		cout << n << " KHONG la so hoan chinh";
	}
	return 0;
}