#include "bai01.h"
void nhapSoDuong(long long& n) {
	do {
		cout << "Nhap so duong n=";
		cin >> n;
		if (n < 1 || n>10000000) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n < 1 || n>10000000);
}
bool ktSoHoanChinh(long long n) {
	bool k = false;
	long long S = 0, P = 1;
	for (int i = 1; i < n; i++) {
		if (n % i == 0) {
			S += i;
			P *= i;
		}
	}
	if (S == P) {
		k = true;
	}
	else {
		k = false;
	}
	return k;
}