#ifndef _BAI01_H_
#define _BAI01_H_
#endif
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;
void nhapSoDuong(long long& n);
bool ktSoHoanChinh(long long n);