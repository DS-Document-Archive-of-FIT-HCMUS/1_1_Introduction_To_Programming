#ifndef _FUNCTION_H_
#define _FUNCTION_H_
#endif
#include <stdio.h>
#include <math.h>
#define MAX 100
//Bai 1
void nhap3SoNguyen(int& a, int& b, int& c);
void xuat3SoVaoFile(FILE* f, int a, int b, int c);
//Bai 2
void doc3SoNguyen(FILE* f, int& a, int& b, int& c);
void giaiPhuongTrinhBac2(FILE* f, int a, int b, int c);
//Bai 3
void docMangSoNguyenTuFile(FILE* f, int a[], int& n);
void sapXepTangDanMangSoNguyen(int a[], int n);
void xuatMangSoNguyenTangDanVaoFile(FILE* f, int a[], int n);
//Bai 4
void nhapCacDongVanBan(char a[MAX][MAX], int& n);
void xuatVanBanVaoFile(FILE* f, char a[MAX][MAX], int n);
//Bai 5
void xuatFileRaManHinh(FILE* f);
//Bai 6
int demSoChuTrongFile(FILE* f); 
//Bai 7
int demSoTuTrongFile(FILE* f);
//Bai 8
void upcaseFile(FILE* f1, FILE* f2);
//Bai 9 
void ghep2FileVanBan(FILE* f1, FILE* f2, FILE* f); 
