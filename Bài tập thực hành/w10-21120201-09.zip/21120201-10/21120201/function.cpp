#include "function.h"
//Bai 1
void nhap3SoNguyen(int& a, int& b, int& c) {
	printf("Nhap so nguyen thu nhat: ");
	scanf_s("%d", &a);
	printf("Nhap so nguyen thu nhat: ");
	scanf_s("%d", &b);
	printf("Nhap so nguyen thu nhat: ");
	scanf_s("%d", &c);
}
void xuat3SoVaoFile(FILE* f, int a, int b, int c) {
	fprintf(f, "%d\t%d\t%d", a, b, c);
}
//Bai 2
void doc3SoNguyen(FILE* f, int& a, int& b, int& c) {
	fscanf_s(f, "%d", &a);
	fscanf_s(f, "%d", &b);
	fscanf_s(f, "%d", &c);
}
void giaiPhuongTrinhBac2(FILE* f, int a, int b, int c) { 
	//Luu lai ket qua vao file
	if (a == 0) {
		if (b == 0) {
			if (c == 0) {
				fprintf(f, "Phuong trinh co vo so nghiem");
			}
			else {
				fprintf(f, "Phuong trinh vo nghiem");
			} 
		}
		else {
			fprintf(f, "Phuong trinh co nghiem duy nhat la x = %.3f", (float)(-1.0 * c / b));
		}
	}
	else {
		int D = b * b - 4 * a * c;
		if (D < 0) {
			fprintf(f, "Phuong trinh vo nghiem");
		}
		else if (D == 0) {
			fprintf(f, "Phuong trinh co nghiem kep la x = %.3f", (float)(-1.0 * b / (2.0 * a)));
		}
		else {
			fprintf(f, "Phuong trinh co 2 nghiem phan biet la x1 = %.3f va x2 = %.3f", (float)(-1.0 * b + sqrt(D)) / (2.0 * a), (float)(-1.0 * b - sqrt(D)) / (2.0 * a));
		}
	}
}
//Bai 3
void docMangSoNguyenTuFile(FILE* f, int a[], int& n) {
	fscanf_s(f, "%d", &n);
	for (int i = 0; i < n; i++) {
		fscanf_s(f, "%d", &a[i]);
	}
}
void sapXepTangDanMangSoNguyen(int a[], int n) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (a[i] > a[j]) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
void xuatMangSoNguyenTangDanVaoFile(FILE* f, int a[], int n) {
	fprintf(f, "Mang so nguyen sau khi sap xep la:\n");
	for (int i = 0; i < n; i++) {
		fprintf(f, "%d ", a[i]);
	}
}
//Bai 4
void nhapCacDongVanBan(char a[MAX][MAX], int &n) {
	do {
		printf("Nhap so dong cua van ban la: ");
		scanf_s("%d", &n);
		if (n < 1) {
			printf("So dong phai lon hon 0, vui long nhap lai!\n");
		}
	} while (n < 1);
	fgets(a[0], MAX, stdin);
	fgets(a[0], MAX, stdin);
	for (int i = 1; i < n; i++) {
		fgets(a[i], MAX, stdin);
	}
}
void xuatVanBanVaoFile(FILE* f, char a[MAX][MAX], int n) {
	for (int i = 0; i < n; i++) {
		fprintf(f, "%s", a[i]);
	}
}
//Bai 5
void xuatFileRaManHinh(FILE* f) {
	char text;
	printf("File in ra man hinh la:\n");
	while (true) {
		text = fgetc(f);
		if (!feof(f)) {
			putc(text, stdout);
		}
		else {
			printf("\n");
			break;
		}
	}
}
//Bai 6
int demSoChuTrongFile(FILE* f) {
	int dem = 0;
	while (!feof(f)) {
		int ch = getc(f);
		if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
			dem++;
		}
	}
	return dem;
}
//Bai 7
int demSoTuTrongFile(FILE* f) {
	int dem = 0;
	bool k = 0;
	while (!feof(f)) {
		char ch = getc(f);
		if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) { 
			k = 1;
		}
		if ((ch == ' ' || ch == '\t' || ch == '\n' || ch == EOF) && k == 1) {
			dem++;
			k = 0;
		}
	}
	return dem;
}
//Bai 8
void upcaseFile(FILE* f1, FILE* f2) {
	char text;
	while (true) {
		text = fgetc(f1);
		if (!feof(f1)) {
			if (text >= 'a' && text <= 'z') {
				putc(text - 32, f2);
			}
			else {
				putc(text, f2);
			}
		}
		else {
			break;
		}
	}
}
//Bai 9
void ghep2FileVanBan(FILE* f1, FILE* f2, FILE* f) {
	char text1, text2;
	while (true) {
		text1 = fgetc(f1);
		if (!feof(f1)) {
			putc(text1, f);
		}
		else {
			putc('\n', f);
			break;
		}
	}
	while (true) {
		text2 = fgetc(f2);
		if (!feof(f2)) {
			putc(text2, f);
		}
		else {
			break;
		}
	}
}





