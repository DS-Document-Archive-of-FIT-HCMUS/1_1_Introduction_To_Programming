#include "function.h"
int main() {
	int choice;
	while (true) {
		printf("1. Ghi 3 so nguyen nhap tu ban phim vao trong file\n");
		printf("2. Doc 3 so nguyen tu file va luu ket cua phuong trinh ax2+bx+c=0 vao trong file\n");
		printf("3. Doc mang so nguyen tu file, sap xep tang dan va ghi mang vao file\n");
		printf("4. Nhap n dong van ban tu ban phim va xuat van ban do vao file\n");
		printf("5. Xuat noi dung cua mot file len man hinh\n");
		printf("6. Dem so chu cai cua file va xuat ket qua ra mot file khac\n");
		printf("7. Dem so tu cua file va xuat ket qua ra mot file khac\n");
		printf("8. Sao chep van ban tu mot file thanh mot file moi sao cho tat ca cac ky tu deu in hoa\n");
		printf("9. Ghep 2 tap tin van ban, noi dung tap tin thu 2 dung sau tap tin thu nhat\n");
		printf("0. Exit\n"); 
		printf("Nhap vao lua chon cua ban: ");
		scanf_s("%d", &choice);
		if (choice == 1) {
			int a1, b1, c1;
			nhap3SoNguyen(a1, b1, c1);
			FILE* fout1;
			fopen_s(&fout1, "fileoutBai1.txt", "wt");
			if (fout1 != NULL) {
				xuat3SoVaoFile(fout1, a1, b1, c1);
				fflush(fout1);
				printf("Xuat file thanh cong...\n");
				fclose(fout1);
			}
		}
		else if (choice == 2) {
			int a2{}, b2{}, c2{};
			FILE* fin2;
			fopen_s(&fin2, "fileinBai2.txt", "rt");
			if (fin2 == NULL) {
				printf("Khong the mo file\n");
			}
			else {
				doc3SoNguyen(fin2, a2, b2, c2);
				fclose(fin2);
			}
			FILE* fout2;
			fopen_s(&fout2, "fileoutBai2.txt", "wt");
			if (fout2 != NULL) {
				giaiPhuongTrinhBac2(fout2, a2, b2, c2);
				fflush(fout2);
				printf("Xuat file thanh cong...\n");
				fclose(fout2);
			}
		}
		else if (choice == 3) {
			int a3[MAX];
			int n3{};
			FILE* fin3;
			fopen_s(&fin3, "fileinBai3.txt", "rt");
			if (fin3 == NULL) {
				printf("Khong the mo file\n");
			}
			else {
				docMangSoNguyenTuFile(fin3, a3, n3);
				fclose(fin3);
			}
			FILE* fout3;
			fopen_s(&fout3, "fileoutBai3.txt", "wt");
			if (fout3 != NULL) {
				sapXepTangDanMangSoNguyen(a3, n3);
				xuatMangSoNguyenTangDanVaoFile(fout3, a3, n3);
				fflush(fout3);
				printf("Xuat file thanh cong...\n");
				fclose(fout3); 
			}
		}
		else if (choice == 4) {
			char a4[MAX][MAX];
			int n4; 
			nhapCacDongVanBan(a4, n4);
			FILE* fout4;
			fopen_s(&fout4, "fileoutBai4.txt", "wt");
			if (fout4 != NULL) {
				xuatVanBanVaoFile(fout4, a4, n4);
				
				printf("Xuat file thanh cong...\n");
				fclose(fout4); 
			}
		}
		else if (choice == 5) {
			FILE* fin5;
			fopen_s(&fin5, "fileinBai5.txt", "rt");
			if (fin5 == NULL) {
				printf("Khong the mo file\n");
			}
			else {
				xuatFileRaManHinh(fin5);
				fclose(fin5); 
			}
		}
		else if (choice == 6) {
			FILE* fin6;
			fopen_s(&fin6, "fileinBai6.txt", "rt");
			if (fin6 == NULL) {
				printf("Khong the mo file\n");
			}
			else {
				FILE* fout6;
				fopen_s(&fout6, "fileoutBai6.txt", "wt");
				if (fout6 != NULL) {
					fprintf(fout6, "So ky tu chu trong file la: %d", demSoChuTrongFile(fin6));
					fflush(fout6);
					printf("Xuat file thanh cong...\n");
					fclose(fout6);
				}
				fclose(fin6);
			}
		}
		else if (choice == 7) {
			FILE* fin7;
			fopen_s(&fin7, "fileinBai7.txt", "rt");
			if (fin7 == NULL) {
				printf("Khong the mo file\n");
			}
			else {
				FILE* fout7;
				fopen_s(&fout7, "fileoutBai7.txt", "wt");
				if (fout7 != NULL) {
					fprintf(fout7, "So tu co trong file la: %d", demSoTuTrongFile(fin7));
					fflush(fout7);
					printf("Xuat file thanh cong...\n");
					fclose(fout7);
				}
				fclose(fin7);
			}
		}
		else if (choice == 8) {
			FILE* fin8;
			fopen_s(&fin8, "fileinBai8.txt", "rt");
			if (fin8 == NULL) {
				printf("Khong the mo file\n");
			}
			else {
				FILE* fout8;
				fopen_s(&fout8, "fileoutBai8.txt", "wt");
				if (fout8 != NULL) {
					upcaseFile(fin8, fout8);
					fflush(fout8);
					printf("Xuat file thanh cong...\n");
					fclose(fout8);
				}
				fclose(fin8);
			}
		}
		else if (choice == 9) {
			FILE* fin9_1;
			fopen_s(&fin9_1, "filein1Bai9.txt", "rt");
			FILE* fin9_2;
			fopen_s(&fin9_2, "filein2Bai9.txt", "rt");
			if (fin9_1 == NULL || fin9_2 == NULL) {
				printf("Ton tai file khong the mo duoc\n");
			}
			else {
				FILE* fout9;
				fopen_s(&fout9, "fileoutBai9.txt", "wt");
				if (fout9 != NULL) {
					ghep2FileVanBan(fin9_1, fin9_2, fout9);
					fflush(fout9);
					printf("Xuat file thanh cong...\n");
					fclose(fout9);
				}
				fclose(fin9_1);
				fclose(fin9_2);
			}
		}
		else if (choice == 0) {
			printf("Ket thuc\n");
			break;
		}
		else {
			printf("Ban nhap gia tri sai, vui long nhap lai!\n");
		}
	}
	return 0;
}
