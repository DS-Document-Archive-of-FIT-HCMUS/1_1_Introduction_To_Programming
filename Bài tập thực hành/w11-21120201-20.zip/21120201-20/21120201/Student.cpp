#include "Student.h"
#include "Date.h"
//Bai 15
void chuanHoaChuoi(char str[]) {
	int i;
	while (str[0] == ' ') {
		for (i = 0; i < strlen(str) - 1; i++) {
			str[i] = str[i + 1];
		}
		str[strlen(str) - 1] = '\0';
	}
	while (str[strlen(str) - 1] == ' ') {
		str[strlen(str) - 1] = '\0';
	}
	i = 0;
	while (i < strlen(str) - 1) {
		if (str[i] == ' ') {
			if (str[i + 1] == ' ') {
				for (int j = i + 1; j < strlen(str) - 1; j++) {
					str[j] = str[j + 1];
				}
				str[strlen(str) - 1] = '\0';
			}
			else {
				i++;
			}
		}
		else {
			i++;
		}
	}
	//strlwr_s(str);
	str[0] = str[0] - 32;
	for (i = 0; i < strlen(str) - 1; i++) {
		if (str[i] == ' ') {
			str[i + 1] = str[i + 1] - 32;
		}
	}
}
void inputStudent(Student& s) {
	do {
		printf("Nhap ID cua sinh vien: ");
		scanf_s("%ld", &s.id);
		if (s.id < 10000000 || s.id>99999999) {
			printf("ID gom 8 chu so. Ban phai nhap lai!\n");
		}
	} while (s.id < 10000000 || s.id>99999999);
	printf("Nhap ten day du cua sinh vien: ");
	fgets(s.fullName, MAX, stdin);
	fgets(s.fullName, MAX, stdin);
	//chuanHoaChuoi(s.fullName);
	printf("Nhap GPA cua sinh vien: ");
	scanf_s("%f", &s.gpa);
	printf("Nhap dia chi cua sinh vien: ");
	fgets(s.address, MAX, stdin);
	fgets(s.address, MAX, stdin);
	/*chuanHoaChuoi(s.address);*/
	printf("Nhap ngay sinh cua sinh vien: \n");
	inputDate(s.dateOfBirth);
}
//Bai 16
void outputStudent16(Student s) {
	printf("Thong tin sinh vien la: \n");
	printf("		ID: %ld\n", s.id);
	printf("		Ho va ten: "); puts(s.fullName);
	printf("		GPA: %f\n", s.gpa);
	printf("		Dia chi: "); puts(s.address);
	printf("		Ngay sinh: "); outputDate(s.dateOfBirth);
}
//Bai 17
			//char* cutstring(char x[max]) {
			//	char s[max];
			//	int dem = 0;
			//	for (int i = a; i <= b; i++) {
			//		s[dem] = x[i]; 
			//		dem++;
			//	}
			//}
void outputStudent17(Student s) {
	printf("Thong tin sinh vien la: \n");
	printf("		ID: %ld\n", s.id);
	char x[MAX];
	int i = 0;
	while (s.fullName[0] != ' ') {
		x[i] = s.fullName[0]; i++;
		for (int j = 0; j < strlen(s.fullName) - 1; j++) {
			s.fullName[j] = s.fullName[j + 1];
		}
		s.fullName[strlen(s.fullName) - 1] = '\0';
	}
	x[i] = '\0';
	for (int j = 0; j < strlen(s.fullName) - 1; j++) {
		s.fullName[j] = s.fullName[j + 1];
	}
	s.fullName[strlen(s.fullName) - 1] = '\0';
	printf("		Ten: "); puts(x);
	printf("		Ho: "); puts(s.fullName);
	printf("		GPA: %f\n", s.gpa);
	printf("		Dia chi: "); puts(s.address);
	printf("		Ngay sinh: "); outputDate(s.dateOfBirth);
	printf("		So tuoi (tinh den ngay 31/12/2021) : %d year %d month %d day\n", 2021 - s.dateOfBirth.year, 12 - s.dateOfBirth.month, 31 - s.dateOfBirth.day);
}
//Bai 18
void loadStudentFromFile(FILE* f, Student& s) {
	fscanf_s(f, "%ld", &s.id);
	fgets(s.fullName, MAX, f);
	fgets(s.fullName, MAX, f);
	fscanf_s(f, "%f", &s.gpa);
	fgets(s.address, MAX, f);
	fgets(s.address, MAX, f);
	loadDateFromFile(f, s.dateOfBirth);
}
//Bai 19
void saveStudentToFile(FILE* f, Student s) {
	fprintf(f, "%ld\n", s.id);
	fputs(s.fullName, f);
	fprintf(f, "%f\n", s.gpa);
	fputs(s.address, f);
	saveDateToFile(f, s.dateOfBirth);
}
//Bai 20
int extractClass(Student s) {
	return (int)s.id / 1000000;
}
//Bai 21
void compareById(Student s1, Student s2) {
	if (s1.id == s2.id) {
		printf("Khong ton tai 2 sinh vien co ID giong nhau\n");
	}
	else if (s1.id > s2.id) {
		puts(s2.fullName);
		puts(s1.fullName);
	}
	else {
		puts(s1.fullName);
		puts(s2.fullName);
	}
}


