#include "Course.h"
#include "Student.h"
#include "Date.h"
//Bai 27
void loadCourseFromFile(FILE* f, Course& c) {
	fgets(c.id, 6, f);
	fgets(c.id, 6, f);
	fgets(c.name, MAX, f);
	fgets(c.name, MAX, f);
	fscanf_s(f, "%d", &c.n);
	for (int i = 0; i < c.n; i++) {
		loadStudentFromFile(f, c.student[i]);
	}
	char stt[6];
	fgets(stt, 6, f);
	fgets(stt, 6, f);
	if (stt == "open ") {
		c.status = 1;
	}
	else {
		c.status = 0;
	}
	fscanf_s(f, "%d", &c.maximum);
	fscanf_s(f, "%d", &c.minimum);
}
//Bai 28
void inputArrayOfStudent(Student s[], int& n) {
	do {
		printf("So luong phan tu sinh vien la: ");
		scanf_s("%d", &n);
		if (n <= 0) {
			printf("The number of students must be more than 0, type again please!\n");
		}
	} while (n <= 0);
	for (int i = 0; i < n; i++) {
		inputStudent(s[i]);
	}
}

void inputCourse(Course& c) {
	printf("Input Course ID: ");
	fgets(c.id, 6, stdin);
	fgets(c.id, 6, stdin);
	printf("Input Course Name: ");
	fgets(c.name, MAX, stdin);
	fgets(c.name, MAX, stdin);
	printf("Input array of students:\n");
	inputArrayOfStudent(c.student, c.n);
	printf("Input status of course (OPEN = 1, CLOSE = 0): ");
	scanf_s("%d", &c.status);
	do {
		printf("Input maximum students: ");
		scanf_s("%d", &c.maximum);
		if (c.maximum < c.n) {
			printf("Maximum must be more than the number of students! Type again please!\n");
		}
	} while (c.maximum < c.n);
	do {
		printf("Input minimum students: ");
		scanf_s("%d", &c.minimum);
		if (c.minimum < 0 || c.minimum > c.n) {
			printf("Minimum must be more than 0 and less than or as the number of students! Type again please!\n");
		}
	} while (c.minimum < 0 || c.minimum > c.n);
}
void saveCourseToFile(FILE* f, Course c) {
	puts(c.id);
	puts(c.name);
	for (int i = 0; i < c.n; i++) {
		saveStudentToFile(f, c.student[i]);
	}
	if (c.status == 1) {
		fprintf(f, "open\n");
	}
	else {
		fprintf(f, "close\n");
	}
	fprintf(f, "%d", c.maximum);
	fprintf(f, "%d", c.minimum);
}
//Bai 29
void addStudentToCourse(Course& c) {
	if (c.n >= c.maximum) {
		printf("Da FULL sinh vien trong khoa hoc!\n");
	}
	else {
		c.n++;
		inputStudent(c.student[c.n - 1]);
	}
}
//Bai 30
void removeStudentFromArray(Student s[], int& n, int x) {
	for (int i = x; i < n - 1; i++) {
		s[i] = s[i + 1];
	}
	n--;
}
void removeStudentFromCourse(Course& c) {
	if (c.status == 0) {
		printf("Khoa hoc da ket thuc!\n");
	}
	else {
		int x{};
		do {
			printf("Sinh vien bi loai bo la phan tu thu bao nhieu? : ");
			scanf_s("%d", x);
			if (x > c.n) {
				printf("Vi tri cua sinh vien trong mang phai <= so luong phan tu cua mang! Ban phai nhap lai!");
			}
		} while (x > c.n);
		removeStudentFromArray(c.student, c.n, x);
		if (c.minimum >= c.n) {
			c.status = 0;
		}
	}
}
		//void outputArrayOfStudent(Student s[], int n) {
		//	printf("Mang sinh vien la:\n");
		//	for (int i = 0; i < n; i++) {
		//		outputStudent16(s[i]);
		//	}
		//}
//Bai 31
void findBornThisMonth(FILE* f, Course c, Date today) {
	fprintf(f, "Find all students who were born in this month:\n");
	for (int i = 0; i < c.n; i++) {
		if (c.student->dateOfBirth.month == today.month) {
			fprintf(f, "%ld - %s\n", c.student->id, c.student->fullName);
		}
	}
}
//Bai 32
void findBornThisDate(FILE* f, Course c, Date today) {
	fprintf(f, "Find all students who were born in this date:\n");
	for (int i = 0; i < c.n; i++) {
		if (c.student->dateOfBirth.day == today.day) {
			fprintf(f, "%ld - %s\n", c.student->id, c.student->fullName);
		}
	}
}
//Bai 33
bool checkLegalLicence(Student s, Date today) {
	if (-s.dateOfBirth.year + today.year < 18) {
		return 0;
	}
	else if (-s.dateOfBirth.year + today.year > 18) {
		return 1;
	}
	else {
		if (today.month > s.dateOfBirth.month) {
			return 1;
		}
		else if (today.month < s.dateOfBirth.month) {
			return 0;
		}
		else {
			if (today.day >= s.dateOfBirth.day) {
				return 1;
			}
			else {
				return 0;
			}
		}
	}
}
void findLegalLicence(FILE* f, Course c, Date today) {
	printf("Find all students who are legal to have driving licences (>= 18 years old)");
	for (int i = 0; i < c.n; i++) {
		if (checkLegalLicence(c.student[i], today)) {
			fprintf(f, "%ld - %s\n", c.student->id, c.student->fullName);
		}
	}
}