#ifndef _STUDENT_H_
#define _STUDENT_H_
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "Date.h"
#define MAX 100
struct Student {
	long id;
	char fullName[MAX];
	float gpa;
	char address[MAX];
	Date dateOfBirth;
};
//Bai 15
void chuanHoaChuoi(char str[]);
void inputStudent(Student& s);
//Bai 16
void outputStudent16(Student s);
//Bai 17
void outputStudent17(Student s);
//Bai 18
void loadStudentFromFile(FILE* f, Student& s);
void saveStudentToFile(FILE* f, Student s);
//Bai 19
void saveStudentToFile(FILE* f, Student s);
//Bai 20
int extractClass(Student s);
//Bai 21
void compareById(Student s1, Student s2);
#endif


