#include "Date.h"
//Bai 1
bool checkLeapYear(Date d) {
	if (d.year % 4 != 0) {
		return 0;
	}
	else {
		if (d.year % 100 == 0 && d.year % 400 != 0) {
			return 0;
		}
		else {
			return 1;
		}
	}
}
int checkMonth(Date d) {
	switch (d.month) {
	case 1: case 3: case 5: case 7: case 8: case 10: case 12: {
		return 31;
		break;
	} 
	case 4: case 6: case 9: case 11: {
		return 30;
		break;
	}
	case 2: {
		if (checkLeapYear(d)) {
			return 29;
			break;
		}
		else {
			return 28;
			break;
		}
	}
	default: {
		return 0;
	}
	}
}
bool checkDay(Date d) {
	if (d.day >= 1 && d.day <= checkMonth(d)) {
		return 1;
	}
	else {
		return 0;
	}
}
void inputDate(Date &d) {
	do {
		printf("Nhap ngay: ");
		scanf_s("%d", &d.day);
		printf("Nhap thang: ");
		scanf_s("%d", &d.month);
		printf("Nhap nam: ");
		scanf_s("%d", &d.year);
		if (!checkDay(d) || d.year < 0) {
			printf("Ngay ban nhap khong ton tai, xin hay nhap lai!\n");
		}
	} while (!checkDay(d));
}
//Bai 2
void outputDate(Date d) {
	//year
	if (d.year == 0) {
		printf("0000");
	}
	else if (d.year < 10) {
		printf("000%d", d.year);
	}
	else if (d.year < 100) {
		printf("00%d", d.year);
	}
	else if (d.year < 1000) {
		printf("0%d", d.year);
	}
	else {
		printf("%d", d.year);
	}
	printf("-");
	//month
	if (d.month < 10) {
		printf("0%d", d.month);
	}
	else {
		printf("%d", d.month);
	}
	//day
	printf("-");
	if (d.day < 10) {
		printf("0%d\n", d.day);
	}
	else {
		printf("%d\n", d.day);
	}
	printf("\n");
}
//Bai 4
void loadDateFromFile(FILE* f, Date &d) {
	fscanf_s(f, "%d", &d.day);
	fscanf_s(f, "%d", &d.month);
	fscanf_s(f, "%d", &d.year);
}
//Bai 5
void saveDateToFile(FILE* f, Date d) {
	fprintf(f, "%d/%d/%d", d.day, d.month, d.year);
}
//Bai 6
int countLeapYear(Date d) {
	int years = d.year;
	if (d.month <= 2) {
		years--;
	}
	return years / 4 - years / 100 + years / 400;
}
void compareTwoDate(Date d1, Date d2) {
	const int daysOfMonth[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
	long long n1 = (long long) d1.year * 365 + d1.day + countLeapYear(d1);
	for (int i = 1; i < d1.month; i++) {
		n1 += daysOfMonth[i - 1];
	}
	long long n2 = (long long) d2.year * 365 + d2.day + countLeapYear(d2);
	for (int i = 1; i < d2.month; i++) {
		n2 += daysOfMonth[i - 1];
	}
	if (n1 > n2) {
		printf("%d/%d/%d", d1.day, d1.month, d1.year);
		printf(" > ");
		printf("%d/%d/%d", d2.day, d2.month, d2.year);
		printf(" %lld ngay\n", n1 - n2);
	}
	else {
		printf("%d/%d/%d", d1.day, d1.month, d1.year);
		printf(" < ");
		printf("%d/%d/%d", d2.day, d2.month, d2.year);
		printf(" %lld ngay\n", n2 - n1); 
	}
}
//Bai 7
Date findTomorrow(Date d0) {
	Date d = d0;
	if (d.day == checkMonth(d)) {
		if (d.month == 12) {
			d.year++;
			d.month = 1;
			d.day = 1;
		}
		else {
			d.month++;
			d.day = 1;
		}
	}
	else {
		d.day++;
	}
	return d;
}
//Bai 8 
Date findYesterday(Date d0) {
	Date d = d0;
	if (d.day == 1) {
		if (d.month == 1) {
			d.year--;
			d.month = 12;
			d.day = 31;
		}
		else {
			d.month--;
			d.day = checkMonth(d);
		}
	}
	else {
		d.day--;
	}
	return d;
}