#include "Date.h"
#include "Student.h"
#include "Course.h"
int main() {
	int choice;

	printf("STRUCT DATE\n");
	printf("1. Input a date.\n");
	printf("2. Output a date (yyyy-MM-dd).\n");
	printf("4. Load a date from a text file.\n");
	printf("5. Save a date to another text file.\n");
	printf("6. Compare 2 date.\n");
	printf("7. Find tomorrow: increase a date by 1 day.\n");
	printf("8. Find yesterday: decrease a date by 1 day.\n");
	printf("STRUCT STUDENT\n");
	printf("15. Input a student.\n");
	printf("16. Output a student: id, full name, gpa, address, dob.\n");
	printf("17. Output a student: id, first name (first word), last name (remaining words), gpa, address, dob, age(18 year 2 months, 2 days).\n");
	printf("18. Load a student from a text file.\n");
	printf("19. Save a student to a text file.\n");
	printf("20. Extract the class of input student. For example, if your id is 19127001, you are in K19 class.\n");
	printf("21. Compare 2 students by id.\n");
	printf("STRUCT COURSE\n");
	printf("27. Load a course from text file.\n");
	printf("28. Save a course to text file.\n");
	printf("29. Add a student to a course.Check the maximum number of students in the course condition.\n");
	printf("30. Remove a student to a course.Check minimum number of students in the course to update the course status : open or close.\n");
	printf("31. Get the current date in your computer.Find all students who were born in this month and save to a text file.\n");
	printf("32. Get the current date in your computer.Find all students who were born in this date and save to a text file.\n");
	printf("33. Get the current date in your computer.Find all students who are legal to have driving licences (>= 18 years old) and save to a text file.\n");
	printf("0. EXIT\n");

	while (true) {

		printf("Input your choice: ");
		scanf_s("%d", &choice);

		switch (choice) {
		case 1: {
			Date d1;
			inputDate(d1);
			break;
		}
		case 2: {
			Date d2;
			inputDate(d2);
			printf("Ngay theo dinh dang (yyyy-MM-dd) la: ");
			outputDate(d2);
			break;
		}
		case 4: {
			Date d4;
			FILE* fin4;
			fopen_s(&fin4, "fileinBai4.txt", "r");
			if (fin4 == NULL) {
				printf("Khong the mo file!\n");
			}
			else {
				loadDateFromFile(fin4, d4);
				printf("Mo file thanh cong...\n");
				fclose(fin4);
			}
			break;
		}
		case 5: {
			Date d5;
			FILE* fout5;
			fopen_s(&fout5, "fileoutBai5.txt", "w");
			if (fout5 != NULL) {
				inputDate(d5);
				saveDateToFile(fout5, d5);
				printf("Xuat file thanh cong...\n");
				fflush(fout5);
				fclose(fout5);
			}
			break;
		}
		case 6: {
			Date d6_1, d6_2;
			printf("Nhap ngay thu nhat:\n");
			inputDate(d6_1);
			printf("Nhap ngay thu hai:\n");
			inputDate(d6_2);
			compareTwoDate(d6_1, d6_2);
			break;
		}
		case 7: {
			Date d7;
			inputDate(d7);
			printf("Tomorrow is: %d/%d/%d\n", findTomorrow(d7).day, findTomorrow(d7).month, findTomorrow(d7).year);
			break;
		}
		case 8: {
			Date d8;
			inputDate(d8);
			printf("Yesterday is: %d/%d/%d\n", findTomorrow(d8).day, findTomorrow(d8).month, findTomorrow(d8).year);
			break;
		}
		case 15: {
			Student s15;
			inputStudent(s15);
			break;
		}
		case 16: {
			Student s16;
			inputStudent(s16);
			outputStudent16(s16);
			break;
		}
		case 17: {
			Student s17;
			inputStudent(s17);
			outputStudent17(s17);
			break;
		}
		case 18: {
			Student s18;
			FILE* fin18;
			fopen_s(&fin18, "fileinBai18.txt", "r");
			if (fin18 == NULL) {
				printf("Khong the mo file!\n");
			}
			else {
				loadStudentFromFile(fin18, s18);
				fclose(fin18);
			}
			break;
		}
		case 19: {
			Student s19;
			FILE* fout19;
			fopen_s(&fout19, "fileoutBai19.txt", "w");
			if (fout19 != NULL) {
				inputStudent(s19);
				saveStudentToFile(fout19, s19);
				printf("Xuat file thanh cong...\n");
				fflush(fout19);
				fclose(fout19);
			}
			break;
		}
		case 20: {
			Student s20;
			inputStudent(s20);
			printf("=> Sinh vien thuoc khoa K%d\n", extractClass(s20));
			break;
		}
		case 21: {
			Student s21_1, s21_2;
			printf("Nhap thong tin sinh vien thu nhat:\n");
			inputStudent(s21_1);
			printf("Nhap thong tin sinh vien thu hai:\n");
			inputStudent(s21_2);
			compareById(s21_1, s21_2);
			break;
		}
		case 27: {
			Course c27;
			FILE* fin27;
			fopen_s(&fin27, "fileinBai27.txt", "r");
			if (fin27 == NULL) {
				printf("Khong the mo file!\n");
			}
			else {
				loadCourseFromFile(fin27, c27);
				fclose(fin27);
			}
			break;
		}
		case 28: {
			Course c28;
			FILE* fout28;
			fopen_s(&fout28, "fileoutBai28.txt", "w");
			if (fout28 != NULL) {
				inputCourse(c28);
				saveCourseToFile(fout28, c28);
				printf("Xuat file thanh cong...\n");
				fflush(fout28);
				fclose(fout28);
			}
			break;
		}
		case 29: {
			Course c29;
			inputCourse(c29);
			addStudentToCourse(c29);
			break;
		}
		case 30: {
			Course c30;
			inputCourse(c30);
			removeStudentFromCourse(c30);
			break;
		}
		case 31: {
			Course c31;
			Date d31;
			FILE* fout31;
			fopen_s(&fout31, "fileoutBai31.txt", "w");
			if (fout31 != NULL) {
				inputCourse(c31);
				printf("Input Today:\n");
				inputDate(d31);
				findBornThisMonth(fout31, c31, d31);
				printf("Xuat file thanh cong...\n");
				fflush(fout31);
				fclose(fout31);
			}
			break;
		}
		case 32: {
			Course c32;
			Date d32;
			FILE* fout32;
			fopen_s(&fout32, "fileoutBai32.txt", "w");
			if (fout32 != NULL) {
				inputCourse(c32);
				printf("Input Today:\n");
				inputDate(d32);
				findBornThisDate(fout32, c32, d32);
				printf("Xuat file thanh cong...\n");
				fflush(fout32);
				fclose(fout32);
			}
			break;
		}
		case 33: {
			Course c33;
			Date d33;
			FILE* fout33;
			fopen_s(&fout33, "fileoutBai33.txt", "w");
			if (fout33 != NULL) {
				inputCourse(c33);
				printf("Input Today:\n");
				inputDate(d33);
				findLegalLicence(fout33, c33, d33);
				printf("Xuat file thanh cong...\n");
				fflush(fout33);
				fclose(fout33);
			}
			break;
		}
		case 0: return 0;
		default: {
			printf("Invalid choice, please type again!\n");
		}
		}
	}
	return 0;
}