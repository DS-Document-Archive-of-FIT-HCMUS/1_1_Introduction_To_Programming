#ifndef _DATE_H_
#define _DATE_H_
#include <stdio.h>
#include <math.h>
#define MAX 100
struct Date {
	int day;
	int month;
	int year;
};
//Bai 1
bool checkLeapYear(Date d);
int checkMonth(Date d);
bool checkDay(Date d);
void inputDate(Date& d);
//Bai 2
void outputDate(Date d);
//Bai 4
void loadDateFromFile(FILE* f, Date& d);
//Bai 5
void saveDateToFile(FILE* f, Date d);
//Bai 6
int countLeapYear(Date d);
void compareTwoDate(Date d1, Date d2);
//Bai 7
Date findTomorrow(Date d0);
//Bai 8
Date findYesterday(Date d0);
#endif
