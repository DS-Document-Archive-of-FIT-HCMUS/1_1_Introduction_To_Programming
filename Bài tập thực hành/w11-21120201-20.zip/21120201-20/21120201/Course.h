#ifndef _COURSE_H_
#define _COURSE_H_
#include <stdio.h>
#include <math.h>
#include "Student.h"
#include "Date.h"
#include <dos.h>
#define MAX 100
struct Course {
	char id[6];
	char name[MAX];
	int n;
	Student student[MAX];
	bool status;
	int maximum;
	int minimum;
};
//Bai 27
void loadCourseFromFile(FILE* f, Course& c);
//Bai 28
void inputArrayOfStudent(Student s[], int& n);
void inputCourse(Course& c);
void saveCourseToFile(FILE* f, Course c);
//Bai 29
void addStudentToCourse(Course& c);
//Bai 30
void removeStudentFromArray(Student s[], int& n, int x);
void removeStudentFromCourse(Course& c);
//Bai 31
void findBornThisMonth(FILE* f, Course c, Date today);
//Bai 32
void findBornThisDate(FILE* f, Course c, Date today);
//Bai 33
bool checkLegalLicence(Student s, Date today);
void findLegalLicence(FILE* f, Course c, Date today);
#endif