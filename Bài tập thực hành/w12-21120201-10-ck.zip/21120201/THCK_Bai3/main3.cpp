#include "function3.h"
int main() {
	Ticket t[MAX];
	int n;
	nhapDanhSachCacVe(t, n);
	printf("Ve co gia tien cao nhat dau tien trong danh sach la: \n");
	xuat1Ve(veCoGiaCaoNhatDauTien(t, n));
	int x;
	printf("Nhap vi tri cua ve can xuat trong danh sach: ");
	do {
		scanf_s("%d", &x);
		if (x<0 || x>n - 1) {
			printf("Gia tri nam trong doan tu 0 den n-1, ban phai nhap lai gia tri: ");
		}
	} while (x<0 || x>n - 1);
	xuat1Ve(t[x]);
	return 0;
}