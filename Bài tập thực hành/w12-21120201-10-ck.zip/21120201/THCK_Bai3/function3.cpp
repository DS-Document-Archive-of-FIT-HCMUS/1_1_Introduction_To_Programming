#include "function3.h"
void nhap1Ve(Ticket& t) {
	printf("Nhap ma ve: ");
	scanf_s("%d", &t.maVe);
	printf("Nhap ten phim: ");
	fgets(t.tenPhim, MAX, stdin);
	fgets(t.tenPhim, MAX, stdin);
	t.tenPhim[strlen(t.tenPhim) - 1] = '\0';
	printf("Nhap gia tien: ");
	scanf_s("%d", &t.giaTien);
	printf("Nhap phong chieu: ");
	fgets(t.phongChieu, MAX, stdin);
	fgets(t.phongChieu, MAX, stdin);
	t.phongChieu[strlen(t.phongChieu) - 1] = '\0';
}
void nhapDanhSachCacVe(Ticket t[], int& n) {
	printf("Nhap vao tong so ve la: ");
	do {
		scanf_s("%d", &n);
		if (n <= 0) {
			printf("n>0, ban phai nhap lai gia tri la: ");
		}
	} while (n <= 0);
	for (int i = 0; i < n; i++) {
		printf("Nhap thong tin ve thu %d\n", i + 1);
		nhap1Ve(t[i]);
	}
}
void xuat1Ve(Ticket t) {
	printf("Thong tin cua ve can tim la: ");
	printf("Ma ve %d, Ten phim %s, Gia tien %d, Phong chieu %s\n", t.maVe, t.tenPhim, t.giaTien, t.phongChieu);
}
Ticket veCoGiaCaoNhatDauTien(Ticket t[], int n) {
	Ticket max = t[n - 1];
	for (int i = 0; i < n; i++) {
		if (max.giaTien < t[i].giaTien) {
			max = t[i];
		}
	}
	return max; 
}