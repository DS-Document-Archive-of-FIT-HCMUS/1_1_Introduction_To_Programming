#ifndef _FUNCTION3_H_
#define _FUNCTION3_H_
#include <stdio.h>
#include <math.h>
#include <string.h>
#define MAX 100
struct Ticket {
	int maVe;
	char tenPhim[MAX];
	int giaTien;
	char phongChieu[MAX];
};
void nhap1Ve(Ticket& t);
void nhapDanhSachCacVe(Ticket t[], int& n);
void xuat1Ve(Ticket t);
Ticket veCoGiaCaoNhatDauTien(Ticket t[], int n);
#endif