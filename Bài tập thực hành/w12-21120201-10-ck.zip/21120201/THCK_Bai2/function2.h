#ifndef _FUNCTION2_H_
#define _FUNCTION2_H_
#include <stdio.h>
#include <math.h>
#include <string.h>
#define MAX 100
void nhapMangVuong2D(int a[][MAX], int &n);
int tong2DuongCheo(int a[][MAX], int n);
void xuatMangVuong2D(int a[][MAX], int n);
#endif