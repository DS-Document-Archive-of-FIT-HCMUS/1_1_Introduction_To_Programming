#include "function2.h"
void nhapMangVuong2D(int a[][MAX], int &n) {
	printf("Nhap vao gia tri cua n = ");
	do {
		scanf_s("%d", &n);
		if (n <= 0) {
			printf("n>0, ban phai nhap lai gia tri cua n = ");
		}
	} while (n <= 0);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("\tNhap a[%d][%d] = ", i, j);
			scanf_s("%d", &a[i][j]);
		}
	}
}
int tong2DuongCheo(int a[][MAX], int n) {
	int sum = 0;
	for (int i = 0; i < n; i++) {
		sum += a[i][i] + a[i][n - 1 - i];
	}
	if (n % 2 == 1) {
		sum -= a[(n - 1) / 2][(n - 1) / 2];
	}
	return sum;
}
void xuatMangVuong2D(int a[][MAX], int n) {
	printf("Mang vuong 2 chieu da nhap la: \n");
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("%d\t", a[i][j]);
		}
		printf("\n");
	}
}


