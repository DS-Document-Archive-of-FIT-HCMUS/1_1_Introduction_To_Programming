#include "function2.h"
int main() {
	int a[MAX][MAX];
	int n;
	nhapMangVuong2D(a, n);
	xuatMangVuong2D(a, n);
	printf("Tong cac phan tu tren duong cheo theo de bai la: %d", tong2DuongCheo(a, n));
	return 0;
}