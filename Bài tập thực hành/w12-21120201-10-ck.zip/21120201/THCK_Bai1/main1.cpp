#include "function1.h"
int main() {
	int a[MAX];
	int N;
	nhapMang1DSoNguyen(a, N);
	sapXepMang(a, N);
	printf("Sau khi da sap xep theo de bai ta co,\n");
	xuatMang1D(a, N);
	return 0;
}