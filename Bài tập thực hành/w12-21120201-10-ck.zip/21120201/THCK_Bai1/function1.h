#ifndef _FUNCTION1_H_
#define _FUNCTION1_H_
#include <stdio.h>
#include <math.h>
#include <string.h>
#define MAX 100
//a
void nhapMang1DSoNguyen(int a[], int& N);
//b
void sapXepMang(int a[], int N);
//c
void xuatMang1D(int a[], int N);
#endif