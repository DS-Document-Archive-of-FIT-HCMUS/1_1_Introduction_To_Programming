#include "function1.h"
//a
void nhapMang1DSoNguyen(int a[], int& N) {
	printf("Nhap so phan tu cua mang so nguyen la N = ");
	do {
		scanf_s("%d", &N);
		if (N < 5) {
			printf("N>=5, ban phai nhap lai N = ");
		}
	} while (N < 5);
	for (int i = 0; i < N; i++) {
		printf("Nhap a[%d] = ", i);
		scanf_s("%d", &a[i]);
	}
}
//b
void sapXepMang(int a[], int N) {
	for (int i = 0; i < N-1; i++) {
		for (int j = i + 1; j < N; j++) {
			if (a[i] > a[j]) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	int k = 0;
	while (a[k] < 0) {
		k++;
	}
	for (int i = 0; i < k-1; i++) {
		for (int j = i + 1; j < k; j++) {
			if (a[i] < a[j]) {
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
}
//c
void xuatMang1D(int a[], int N) {
	printf("Mang la:\n");
	for (int i = 0; i < N; i++) {
		printf("%d ", a[i]);
	}
} 