#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int n = 0, S = 0;
	int i = 1;
	//Process
	while (S <= 1000) {
		S += i;
		n = i;
		i++;
	}
	//Output
	cout << "n=" << n;
	return 0;
}