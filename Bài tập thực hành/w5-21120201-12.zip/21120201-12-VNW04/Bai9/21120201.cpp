#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	unsigned int n;
	int d = 0;
	int i = 1;
	//Input
	cout << "Nhap n=";
	cin >> n;
	//Process, Output
	if (n == 0 || n == 1) {
		cout << n << " KHONG phai la so nguyen to!";
	}
	else {
		while (i < n && d <= 1) {
			if (n % i == 0) {
				d++;
			}
			i++;
		}
		if (d == 1) {
			cout << n << " la so nguyen to!";
		}
		else {
			cout << n << " KHONG la so nguyen to!";
		}
	}
	return 0;
}