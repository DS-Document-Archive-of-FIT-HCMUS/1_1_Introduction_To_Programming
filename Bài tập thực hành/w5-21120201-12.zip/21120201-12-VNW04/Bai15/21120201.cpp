#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	unsigned int k, f1 = 1, f2 = 1, t;
	cout << "Nhap k=";
	cin >> k;
	if (k == 1 || k == 2) {
		cout << "So hang thu " << k << " cua day Fibonacci la: " << 1;
	}
	else {
		int i = 3;
		while (i <= k) {
			t = f2;
			f2 = f1 + f2;
			f1 = t;
			i++;
		}
		cout << "So hang thu " << k << " cua day Fibonacci la: " << f2;
	}
	return 0;
}