#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	double n;
	int S = 0;
	int i = 0;
	//Input
	cout << "Nhap n=";
	cin >> n;
	//Process, Output
	cout << "Day so nguyen to nho hon " << n << " la:" << endl;
	while (i < n) {
		S = 0;
		int t = 1;
		while (t <= i) {
			if (i % t == 0) {
				S++;
			}
			t++;
		}
		if (S == 2) {
			cout << i << " ";
		}
		i++;
	}
	return 0;
}