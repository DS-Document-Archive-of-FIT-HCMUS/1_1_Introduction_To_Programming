#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int n;
	double x;
	double S = 1, L = 1;
	int i = 1;
	//Input
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
	//Process
	while (i <= n) {
		L *= x;
		S += L;
		i++;
	}
	//Output
	cout << "S=" << S;
	return 0;
}