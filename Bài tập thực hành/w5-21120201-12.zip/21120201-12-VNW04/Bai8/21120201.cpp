#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int a, b, min, ucln = 1;
	int i = 1;
	//Input
	cout << "Nhap a=";
	cin >> a;
	cout << "Nhap b=";
	cin >> b;
	//Process
	if (a > b) {
		min = b;
	}
	else {
		min = a;
	}
	while (i < min) {
		if (a % i == 0 && b % i == 0) {
			ucln = i;
		}
		i++;
	}
	//Output
	cout << "UCLN(" << a << "," << b << ")=" << ucln << endl;
	cout << "BCNN(" << a << "," << b << ")=" << a * b / ucln;
	return 0;
}