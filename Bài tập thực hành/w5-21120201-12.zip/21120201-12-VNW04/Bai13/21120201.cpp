#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	cout << "BANG CUU CHUONG" << endl;
	cout << "________________________" << endl;
	int i = 1;
	while (i <= 9) {
		cout << "Bang nhan " << i << endl;
		int j = 1;
		while (j <= 10) {
			cout << i << " * " << j << " = " << i * j << endl;
			j++;
		}
		cout << "........................" << endl;
		i++;
	}
	return 0;
}