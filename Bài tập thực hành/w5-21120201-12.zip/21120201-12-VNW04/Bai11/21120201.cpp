#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int i = 0;
	while (i <= 255) {
		cout << "Ky tu: " << (char)i << " - Ma ASCII tuong ung la: " << i << endl;
		i++;
	}
}