#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int N;
	long long S = 0;
	long long L = 1;
	int i = 1;
	//Input 
	cout << "Nhap N=";
	cin >> N;
	//Process
	while (i <= N) {
		L *= i;
		S += L;
		i++;
	}
	//Output
	cout << "S=" << S;
	return 0;
}