#include "Header.h"
int main() {
	int choice = 0;
	while (true) {
		cout << "1. Nhap, xuat mang" << endl;
		cout << "2. Tim phan tu lon nhat cua mang" << endl;
		cout << "3. Tim tong cac so khong am cua mang" << endl;
		cout << "4. Tim tong cac phan tu tai vi tri chan" << endl;
		cout << "5. Tim so luong so nguyen to trong mang" << endl;
		cout << "6. Tim phan tu am lon nhat trong mang, //neu khong co thi tra ve 0//" << endl;
		cout << "7. Tim phan tu khong am nho nhat trong mang, // neu khong co thi tra ve -1//" << endl;
		cout << "8. Kiem tra mang co tang dan khong?" << endl;
		cout << "9. Tong cac so chinh phuong trong mang" << endl;
		cout << "0. Exit" << endl;
		cout << "Nhap vao lua chon cua ban: ";
		cin >> choice;
		int a[MAX];
		int n;
		if (choice == 1) {
			nhapMang(a, n);
			xuatMang(a, n);
		}
		else if (choice == 2) {
			nhapMang(a, n);
			cout << "Phan tu lon nhat cua mang la: " << phanTuLonNhat(a, n) << endl;
		}
		else if (choice == 3) {
			nhapMang(a, n);
			cout << "Tong cac so khong am cua mang la: " << tongSoKhongAm(a, n) << endl;
		}
		else if (choice == 4) {
			nhapMang(a, n);
			cout << "Tong cac phan tu tai vi tri chan la: " << tongViTriChan(a, n) << endl;
		}
		else if (choice == 5) {
			nhapMang(a, n);
			cout << "So luong so nguyen to trong mang la: " << soLuongSoNguyenTo(a, n) << endl;
		}
		else if (choice == 6) {
			nhapMang(a, n);
			cout << "Phan tu am lon nhat trong mang la: " << phanTuAmLonNhat(a, n) << endl;
		}
		else if (choice == 7) {
			nhapMang(a, n);
			cout << "Phan tu khong am nho nhat trong mang la: " << phanTuKhongAmNhoNhat(a, n) << endl;
		}
		else if (choice == 8) {
			nhapMang(a, n);
			if (coTangDanKhong(a, n)) {
				cout << "Mang nay la mang tang dan" << endl;
			}
			else {
				cout << "Mang nay KHONG la mang tang dan" << endl;
			}
		}
		else if (choice == 9) {
			nhapMang(a, n);
			cout << "Tong cac so chinh phuong trong mang la: " << tongSoChinhPhuong(a, n) << endl;
		}
		else if (choice == 0) {
			cout << "Ket thuc" << endl;
			break;
		}
		else {
			cout << "Gia tri khong thoa ban phai nhap lai!" << endl;
		}
	}
	return 0;
}