#ifndef _BTVNTUAN8_H_
#define _BTVNTUAN8_H_
#endif
#include <iostream>
using namespace std;
#define MAX 100
void nhapMang(int a[], int& n);
void xuatMang(int a[], int n);
int phanTuLonNhat(int a[], int n);
int tongSoKhongAm(int a[], int n);
int tongViTriChan(int a[], int n);
bool kiemTraNguyenTo(int a);
int soLuongSoNguyenTo(int a[], int n);
int phanTuAmDauTien(int a[], int n);
int phanTuAmLonNhat(int a[], int n);
int phanTuKhongAmDauTien(int a[], int n);
int phanTuKhongAmNhoNhat(int a[], int n);
bool coTangDanKhong(int a[], int n);
bool kiemTraChinhPhuong(int a);
int tongSoChinhPhuong(int a[], int n);
