#include "Header.h"
void nhapMang(int a[], int& n) {
	do {
		cout << "Nhap so phan tu cua mang la n = ";
		cin >> n;
		if (n <= 0) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n <= 0);
	for (int i = 0; i < n; i++) {
		cout << "Nhap a[" << i << "]=";
		cin >> a[i];
	}
}
void xuatMang(int a[], int n) {
	cout << "Mang la:" << endl;
	for (int i = 0; i < n; i++) {
		cout << a[i] << " ";
	}
	cout << endl;
}
int phanTuLonNhat(int a[], int n) {
	int Max = a[0];
	for (int i = 1; i < n; i++) {
		if (Max < a[i]) {
			Max = a[i];
		}
	}
	return Max;
}
int tongSoKhongAm(int a[], int n) {
	int sumKhongAm = 0;
	for (int i = 0; i < n; i++) {
		if (a[i] >= 0) {
			sumKhongAm += a[i];
		}
	}
	return sumKhongAm;
}
int tongViTriChan(int a[], int n) {
	int sumViTriChan = 0;
	for (int i = 0; i < n; i++) {
		if (i % 2 == 0) {
			sumViTriChan += a[i];
		}
	}
	return sumViTriChan;
}
bool kiemTraNguyenTo(int a) {
	bool kt = true;
	if (a < 2) {
		kt = false;
	}
	else {
		int dem = 0;
		for (int i = 1; i <= a; i++) {
			if (a % i == 0) {
				dem++;
			}
		}
		if (dem == 2) {
			kt = true;
		}
		else {
			kt = false;
		}
	}
	return kt;
}
int soLuongSoNguyenTo(int a[], int n) {
	int dem = 0;
	for (int i = 0; i < n; i++) {
		if (kiemTraNguyenTo(a[i])) {
			dem++;
		}
	}
	return dem;
}
int phanTuAmDauTien(int a[], int n) {
	int amDauTien = 0;
	for (int i = 0; i < n; i++) {
		if (a[i] < 0) {
			amDauTien = a[i];
			break;
		}
	}
	return amDauTien;
}
int phanTuAmLonNhat(int a[], int n) {
	int amLonNhat = phanTuAmDauTien(a, n);
	if (phanTuAmDauTien(a, n) == 0) {
		return 0;
	}
	else {
		for (int i = 0; i < n; i++) {
			if (a[i] > amLonNhat && a[i] < 0) {
				amLonNhat = a[i];
			}
		}
		return amLonNhat;
	}
}
int phanTuKhongAmDauTien(int a[], int n) {
	int khongAmDauTien = -1;
	for (int i = 0; i < n; i++) {
		if (a[i] >= 0) {
			khongAmDauTien = a[i];
			break;
		}
	}
	return khongAmDauTien;
}
int phanTuKhongAmNhoNhat(int a[], int n) {
	int khongAmNhoNhat = phanTuKhongAmDauTien(a, n);
	if (phanTuKhongAmDauTien(a, n) == -1) {
		return -1;
	}
	else {
		for (int i = 0; i < n; i++) {
			if (a[i] < khongAmNhoNhat && a[i] >= 0) {
				khongAmNhoNhat = a[i];
			}
		}
		return khongAmNhoNhat;
	}
}
bool coTangDanKhong(int a[], int n) {
	bool checkTangDan = true;
	for (int i = 0; i < n - 1; i++) {
		if (a[i] > a[i + 1]) {
			checkTangDan = false;
			break;
		}
	}
	return checkTangDan;
}
bool kiemTraChinhPhuong(int a) {
	if (a < 0) {
		return false;
	}
	else {
		if (sqrt(a) - (int)sqrt(a) == 0) {
			return true;
		}
		else {
			return false;
		}
	}
}
int tongSoChinhPhuong(int a[], int n) {
	int sumChinhPhuong = 0;
	for (int i = 0; i < n; i++) {
		if (kiemTraChinhPhuong(a[i])) {
			sumChinhPhuong += a[i];
		}
	}
	return sumChinhPhuong;
}