#include "Function.h"
using namespace std;
// Ho va ten: Bui Dinh Bao
// MSSV: 21120201
// Lop: 21CTT2C
// NOP BAI KIEM TRA GIUA KY
int main() {
	//Bai 1:
	cout << "BAI 1:" << endl;
	int n1;
	nhapSoNguyenN(n1);
	cout << "Tong cac so nguyen to co hang don vi la 3 trong doan tu 2 den n la: " << tongSoNguyenToCoHangDVla3(n1);
	cout << endl;

	//Bai 2:
	cout << "BAI 2:" << endl;
	int x;
	int n2;
	cout << "NHAP GIA TRI CUA x" << endl;
	nhapSoNguyenDuong(x);
	cout << "NHAP GIA TRI CUA n" << endl;
	nhapSoNguyenDuong(n2);
	cout << "Gia tri cua S = " << tinhS(x, n2);
	cout << endl;

	//Bai 3: 
	cout << "BAI 3:" << endl;
	long n3;
	int S;
	hamNhapSoNguyenNvaTinhTongChuSo(n3, S);
	cout << endl;

	//Bai 4:
	cout << "BAI 4:" << endl;
	docTungChuSoTuTraiQuaPhai(S); 
	cout << endl;

	return 0;
}