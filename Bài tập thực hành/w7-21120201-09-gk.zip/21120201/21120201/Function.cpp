#include "Function.h"
//Bai 1:
void nhapSoNguyenN(int& n) {
	do {
		cout << "Nhap so nguyen n=";
		cin >> n;
		if (n < 2 || n > 500) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (n < 2 || n > 500);
}
bool ktSoNguyenTo(int n) {
	int dem = 0;
	for (int i = 1; i <= n; i++) {
		if (n % i == 0) {
			dem++;
		}
	}
	if (dem == 2) {
		return 1;
	}
	else {
		return 0;
	}
}
int tongSoNguyenToCoHangDVla3(int n) {
	int S = 0;
	for (int i = 2; i <= n; i++) {
		if (ktSoNguyenTo(i) && i % 10 == 3) {
			S = S + i;
		}
	}
	return S;
}
//Bai 2:
void nhapSoNguyenDuong(int& x) {
	do {
		cout << "Nhap vao gia tri nguyen duong = ";
		cin >> x;
		if (x <= 0) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (x <= 0);
}
long long tinhS(int x, int n) {
	long long S = 0;
	for (int i = 1; i <= n; i++) {
		S = S + pow(-1, i + 1) * i * pow(x, i);
	}
	return S;
}
//Bai 3:
void hamNhapSoNguyenNvaTinhTongChuSo(long& n, int& S) {
	S = 0;
	do {
		cout << "Nhap vao so nguyen n = ";
		cin >> n;
		if (n <= 99 || n >= 999999) {
			cout << "Ban phai nhap lai!" << endl;
		}
		else {
			long n0 = n;
			while (n0 != 0) {
				S = S + n0 % 10;
				n0 = (n0 - n % 10) / 10;
			}
			cout << "Tong cac chu so cua so nguyen n la: " << S;
		}
	} while (n <= 99 || n >= 999999);
}
//Bai 4:
void docSo(int n) {
	switch (n) {
		case 0: cout << "Zero "; break;
		case 1: cout << "One "; break;
		case 2: cout << "Two "; break;
		case 3: cout << "Three "; break;
		case 4: cout << "Four "; break;
		case 5: cout << "Five "; break;
		case 6: cout << "Six "; break;
		case 7: cout << "Seven "; break;
		case 8: cout << "Eight "; break;
		case 9: cout << "Nine "; break;
		default: cout << " "; break;
	}
}
void docTungChuSoTuTraiQuaPhai(int S) {
	int S1 = 0;
	while (S != 0) {
		S1 = S1 * 10;
		S1 = S1 + S % 10;
		S = (S - S % 10) / 10;
	}
	while (S1 != 0) {
		docSo(S1 % 10);
		S1 = (S1 - S1 % 10) / 10;
	}
}

