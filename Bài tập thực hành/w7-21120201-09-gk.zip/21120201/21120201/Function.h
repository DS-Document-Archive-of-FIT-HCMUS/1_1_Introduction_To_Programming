#ifndef _FUNCTION_H_
#define _FUNCTION_H_
#endif
#include <iostream>
using namespace std;

//Bai 1:
void nhapSoNguyenN(int& n);
bool ktSoNguyenTo(int n);
int tongSoNguyenToCoHangDVla3(int n);

//Bai 2:
void nhapSoNguyenDuong(int& x);
long long tinhS(int x, int n);

//Bai 3:
void hamNhapSoNguyenNvaTinhTongChuSo(long& n, int& S);

//Bai 4:
void docSo(int n);
void docTungChuSoTuTraiQuaPhai(int S);
