#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int n;
	double x;
	double S = 1, L = 1;
	//Input
	cout << "Nhap n=";
	cin >> n;
	cout << "Nhap x=";
	cin >> x;
	//Process
	for (int i = 1; i <= n; i++) {
		L *= x;
		S += L;
	}
	//Output
	cout << "S=" << S;
	return 0;
}