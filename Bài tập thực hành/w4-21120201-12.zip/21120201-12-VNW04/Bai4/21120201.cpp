#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int N;
	long long S = 0;
	long long L = 1;
	//Input 
	cout << "Nhap N=";
	cin >> N;
	//Process
	for (int i = 1; i <= N; i++) {
		L *= i;
		S += L;
	}
	//Output
	cout << "S=" << S;
	return 0;
}