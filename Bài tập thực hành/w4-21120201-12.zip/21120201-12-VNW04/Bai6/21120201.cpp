#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int n;
	long long S = 0;
	long long L = 1;
	//Input 
	cout << "Nhap n=";
	cin >> n;
	//Process
	for (int i = 1; i <= n; i++) {
		L *= i;
		S += L;
	}
	//Output
	cout << "S=" << S;
	return 0;
}