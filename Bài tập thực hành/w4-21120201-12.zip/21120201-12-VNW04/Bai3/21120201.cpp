#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int N;
	double S = 1;
	//Input
	cout << "Nhap N=";
	cin >> N;
	//Process
	for (int i = 1; i <= N - 1; i++) {
		S += 1.0 / (i * (i + 1));
	}
	//Output
	cout << "S=" << S;
	return 0;
}