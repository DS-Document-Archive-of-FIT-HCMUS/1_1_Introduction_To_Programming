#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	int n = 0, S = 0;
	//Process
	for (int i = 1; S <= 1000; i++) {
		S += i;
		n = i;
	}
	//Output
	cout << "n=" << n;
	return 0;
}