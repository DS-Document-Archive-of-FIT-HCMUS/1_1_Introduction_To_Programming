#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	unsigned int N, f1 = 1, f2 = 1, t;
	cout << "Nhap N=";
	cin >> N;
	cout << N << " so dau tien cua day Fibonacci la: " << endl;
	if (N == 1) {
		cout << "1";
	}
	else {
		if (N >= 2) {
			cout << "1 1 ";
		}
		for (int i = 3; i <= N; i++) {
			cout << f1 + f2 << " ";
			t = f2;
			f2 = f1 + f2;
			f1 = t;
		}
	}
	return 0;
}