#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	for (int i = 0; i <= 255; i++) {
		cout << "Ky tu: " << (char)i << " - Ma ASCII tuong ung la: " << i << endl;
	}
}