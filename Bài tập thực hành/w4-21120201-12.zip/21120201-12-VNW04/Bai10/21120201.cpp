#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	double n;
	int S = 0;
	//Input
	cout << "Nhap n=";
	cin >> n;
	//Process, Output
	cout << "Day so nguyen to nho hon " << n << " la:" << endl;
	for (int i = 0; i < n; i++) {
		S = 0;
		for (int t = 1; t <= i; t++) {
			if (i % t == 0) {
				S++;
			}
		}
		if (S == 2) {
			cout << i << " ";
		}
	}
	return 0;
}