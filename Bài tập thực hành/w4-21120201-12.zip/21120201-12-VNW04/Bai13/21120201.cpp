#include <iostream>
#include <stdio.h>
#include <math.h>
#include <iomanip>
using namespace std;
int main() {
	cout << "BANG CUU CHUONG" << endl;
	cout << "________________________" << endl;
	for (int i = 1; i <= 9; i++) {
		cout << "Bang nhan " << i << endl;
		for (int j = 1; j <= 10; j++) {
			cout << i << " * " << j << " = " << i * j << endl;
		}
		cout << "........................" << endl;
	}
	return 0;
}