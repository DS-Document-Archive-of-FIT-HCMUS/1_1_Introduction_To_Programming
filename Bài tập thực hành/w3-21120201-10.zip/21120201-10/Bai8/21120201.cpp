#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	unsigned int m, y;
	//INPUT
	do {
		cout << "Nhap thang: ";
		cin >> m;
	} while (m > 12);
	cout << "Nhap nam: ";
	cin >> y;
	//OUTPUT
	if (m == 2) {
		if ((y % 4 == 0) && (y % 100 != 0)) {
			cout << "Thang nay co 29 ngay";
		}
		else {
			cout << "Thang nay co 28 ngay";
		}
	}
	else {
		switch (m) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12: cout << "Thang nay co 31 ngay"; break;
		case 4:
		case 6:
		case 9:
		case 11: cout << "Thang nay co 30 ngay"; break;
		}
	}
	return 0;
}