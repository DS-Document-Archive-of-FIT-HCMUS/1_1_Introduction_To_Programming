#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	int a, b, c, d;
	//INPUT
	cout << "a,b,c,d:";
	cin >> a >> b >> c >> d;
	//
	if (a > b) {
		a = a ^ b;
		b = a ^ b;
		a = a ^ b;
	}
	if (a > c) {
		a = a ^ c;
		c = a ^ c;
		a = a ^ c;
	}
	if (a > d) {
		a = a ^ d;
		d = a ^ d;
		a = a ^ d;
	}
	if (b > c) {
		b = b ^ c;
		c = b ^ c;
		b = b ^ c;
	}
	if (b > d) {
		b = b ^ d;
		d = b ^ d;
		b = b ^ d;
	}
	if (c > d) {
		c = c ^ d;
		d = c ^ d;
		c = c ^ d;
	}
	//OUTPUT
	cout << "Sap xep tang dan:" << a << " " << b << " " << c << " " << d;
	return 0;
}