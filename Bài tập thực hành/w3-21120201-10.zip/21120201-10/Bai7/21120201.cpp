#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	double a, b, c;
	//INPUT
	do {
		printf("Nhap theo thu tu do dai ba canh cua tam giac = ");
		scanf_s("%lf %lf %lf", &a, &b, &c);
	} while ((a <= 0) && (b <= 0) && (c <= 0));
	//OUTPUT
	if (!((abs(a - b) < c) && (c < (a + b))))
		printf("Khong phai la do dai ba canh cua tam giac\n");
	else
		if ((a == b) && (a == c))
			printf("La do dai ba canh cua tam giac deu\n");
		else {
			if ((a * a == b * b + c * c) || (b * b == a * a + c * c) || (c * c == b * b + a * a)) {
				if ((a == b) || (a == c) || (b == c))
					printf("La do dai ba canh cua tam giac vuong can\n");
				else printf("La do dai ba canh cua tam giac vuong\n");
			}
			else {
				if ((a == b) || (a == c) || (b == c))
					printf("La do dai ba canh cua tam giac can\n");
				else printf("La do dai ba canh cua tam giac thuong\n");
			}
		}
	return 0;
}