#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	unsigned int d, m, y; 
	bool x = true;
	//INPUT
	cout << "Nhap nam: ";
	cin >> y;
	//Nhap so lon hon 0
	do {
		cout << "Nhap thang: ";
		cin >> m;
		if (m > 12) {
			cout << "Ban phai nhap lai" << endl;
		}
	} while (m > 12);
	do {
		cout << "Nhap ngay: ";
		cin >> d;
		if (d > 31) {
			cout << "Ban phai nhap lai" << endl;
			x = false;
		}
		else {
			if (m == 2) {
				if (((y % 4 == 0) && (y % 100 != 0)) || (y % 400 == 0)) {
					if (d > 29) {
						cout << "Ban phai nhap lai" << endl;
						x = false;
					}
					else {
						x = true;
					}
				}
				else {
					if (d > 28) {
						cout << "Ban phai nhap lai" << endl;
						x = false;
					}
					else {
						x = true;
					}
				}
			}
			else {
				if ((m == 4) || (m == 6) || (m == 9) || (m == 11)) {
					if (d > 30) {
						cout << "Ban phai nhap lai" << endl;
						x = false;
					}
					else {
						x = true;
					}
				}
				else {
					x = true;
				}
			}
		}
	} while (x == false);
	//
	cout << "Ngay " << d << " " << "Thang " << m << " " << "Nam " << y << endl;
	x = true;
	int maxd;
	if (m == 2) {
		if ((y % 4 == 0) && (y % 100 != 0)) {
			maxd = 29;
		}
		else {
			maxd = 28;
		}
	}
	else {
		if ((m == 4) || (m == 6) || (m == 9) || (m == 11)) {
			maxd = 30;
		}
		else {
			maxd = 31;
		}
	}
	int d1 = d, m1 = m, y1 = y;
	d1++;
	if (d1 > maxd) {
		d1 = 1; 
		m1++;
	}
	if (m1 > 12) {
		m1 = 1; 
		y1++;
	}
	d--;
	if (d == 0) {
		m--;
		if (m == 0) {
			y--;
			d = 31;
			m = 12;
		}
		else {
			if (m == 2) {
				if (((y % 4 == 0) && (y % 100 != 0)) || (y % 400 == 0)) {
					d = 29;
				}
				else {
					d = 28;
				}
			}
			else {
				if ((m == 4) || (m == 6) || (m == 9) || (m == 11)) {
					d = 30;
				}
				else {
					d = 31;
				}
			}
		}
	}
	printf("After date: %d/%d/%d \n", d1, m1, y1);
	printf("Before date: %d/%d/%d", d, m, y);
	return 0;
}