#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	double km;
	//INPUT
	cout << "Nhap so km la: ";
	cin >> km;
	//OUTPUT
	if (km <= 1) {
		cout << "Tong tien = " << km * 15000;
	}
	else {
		if ((km <= 5) && (km > 1)) {
			cout << "Tong tien = " << 15000 + (km - 1) * 13500;
		}
		else {
			if ((km <= 120) && (km > 5)) {
				cout << "Tong tien = " << 69000 + (km - 6) * 11000;
			}
			else {
				if (km > 120) {
					cout << "Tong tien = " << (1323000 + (km - 120) * 11000) * 9 / 10;
				}
			}
		}
	}
	return 0;
}