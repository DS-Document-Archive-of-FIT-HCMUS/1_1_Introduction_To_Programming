#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	float a, b;
	//INPUT
	printf("Nhap a va b theo thu tu = ");
	scanf_s("%f %f", &a, &b);
	//OUTPUT
	if ((a == 0) && (b == 0)) {
		printf("Phuong trinh co vo so nghiem");
	}
	else {
		if ((a == 0) && (b != 0)) {
			printf("Phuong trinh vo nghiem");
		}
		else {
			printf("Phuong trinh co nghiem duy nhat la x = %f", -b / a);
		}
	}
	return 0;
}