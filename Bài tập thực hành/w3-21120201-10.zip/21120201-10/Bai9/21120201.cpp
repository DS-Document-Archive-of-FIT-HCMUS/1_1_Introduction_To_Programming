#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	int a, b, c, d, min;
	//INPUT
	cout << "Nhap a, b, c, d theo thu tu bang: ";
	cin >> a >> b >> c >> d;
	//
	min = a;
	if (min < b) {
		min = b;
	}
	if (min < c) {
		min = c;
	}
	if (min < d) {
		min = d;
	}
	//OUTPUT
	cout << "Gia tri nho nhat la min = " << min;
	return 0;
}