#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	float a, b, c;
	//INPUT
	printf("Nhap a, b, c theo thu tu = ");
	scanf_s("%f %f %f", &a, &b, &c);
	//
	float D = b * b - 4 * a * c;
	//OUTPUT
	if (a == 0) {
		printf("Day la dang phuong trinh bac nhat mot an");
	} //Gia su a khac 0 
	else {
		if (D < 0) {
			printf("Phuong trinh vo nghiem");
		}
		else {
			if (D == 0) {
				printf("Phuong trinh co nghiem kep la x = %f", -b / (2 * a));
			}
			else {
				printf("Phuong trinh co 2 nghiem phan biet la: \n");
				printf("x1 = %f\n", ((-b + sqrt(D)) / (2 * a)));
				printf("x2 = %f\n", ((-b - sqrt(D)) / (2 * a)));
			}
		}
	}
	return 0;
}