#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	int a;
	//INPUT
	cout << "Nhap so nguyen a = ";
	cin >> a;
	//OUTPUT
	switch (a) {
		case 1: cout << "Mot"; break;
		case 2: cout << "Hai"; break;
		case 3: cout << "Ba"; break;
		case 4: cout << "Bon"; break;
		case 5: cout << "Nam"; break;
		case 6: cout << "Sau"; break;
		case 7: cout << "Bay"; break;
		case 8: cout << "Tam"; break;
		case 9: cout << "Chin"; break;
		default: cout << "Khong doc duoc"; break;
	}
	return 0;
}