#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
//MSSV: 21120201
//Ten: Bui Dinh Bao
//Nop bai tap ve nha W03 THNMCNTT
using namespace std;
int main() {
	char x;
	//INPUT
	cout << "Nhap chu cai x la: ";
	cin >> x;
	//OUTPUT
	if (((int)x <= 90) && ((int)x >= 65)) {
		cout << (char)(x + ' ');
	}
	if (((int)x <= 122) && ((int)x >= 97)) {
		cout << (char)(x - ' ');
	}
	return 0;
}