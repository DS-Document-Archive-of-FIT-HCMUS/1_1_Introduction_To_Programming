#ifndef _FUNCTION_H_
#define _FUNCTION_H_
#endif
#include <iostream>
using namespace std;
#define MAX 100
//BAI 1
void nhapMangSoNguyen2D(int a[][MAX], int& m, int& n);
void xuatMangSoNguyen2D(int a[][MAX], int m, int n);
int phanTuLonNhat(int a[][MAX], int m, int n);
int phanTuNhoNhat(int a[][MAX], int m, int n);
//BAI 2
void nhapMangSoThuc2D(double a[][MAX], int& m, int& n);
void xuatMangSoThuc2D(double a[][MAX], int m, int n);
void sapXepDungMangPhu(double a[][MAX], int m, int n, double b[][MAX]);
void sapXepKhongDungMangPhu(double a[][MAX], int m, int n);
//BAI 3
bool kiemTraDiemYenNgua(int a[][MAX], int m, int n, int current_row, int current_column);
void xuatDiemYenNgua(int a[][MAX], int m, int n);
//BAI 4
bool kiemTraPhanTuCoNghiaThuocMang(int a[][MAX], int m, int n, int current_row, int current_column);
int demSoLuongPhanTuDuongXungQuanh(int a[][MAX], int m, int n, int current_row, int current_column);
void xayDungMaTranB(int a[][MAX], int m, int n, int b[][MAX]);
//BAI 5
int tongCuaDong(int a[][MAX], int m, int n, int ofrow);
void sapXepDongNhoDenLon(int a[][MAX], int m, int n);
