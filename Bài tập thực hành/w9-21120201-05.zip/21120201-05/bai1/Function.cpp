#include "Function.h"
// Bai 1
void nhapMangSoNguyen2D(int a[][MAX], int& m, int& n) {
	do {
		cout << "Nhap so dong m = ";
		cin >> m;
		cout << "Nhap so cot n = ";
		cin >> n;
		if (m <= 0 && n <= 0) {
			cout << "Ban phai nhap lai!" << endl;

		}
	} while (m <= 0 && n <= 0);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << "Nhap vao a[" << i << "][" << j << "] = ";
			cin >> a[i][j];
		}
	}
}
void xuatMangSoNguyen2D(int a[][MAX], int m, int n) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << a[i][j] << "\t";
		}
		cout << endl;
	}
}
int phanTuLonNhat(int a[][MAX], int m, int n) {
	int max = a[0][0];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if (a[i][j] > max) {
				max = a[i][j];
			}
		}
	}
	return max;
}
int phanTuNhoNhat(int a[][MAX], int m, int n) {
	int min = a[0][0];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			if (a[i][j] < min) {
				min = a[i][j];
			}
		}
	}
	return min;
}
// Bai 2
void nhapMangSoThuc2D(double a[][MAX], int& m, int& n) {
	do {
		cout << "Nhap so dong m = ";
		cin >> m;
		cout << "Nhap so cot n = ";
		cin >> n;
		if (m <= 0 && n <= 0) {
			cout << "Ban phai nhap lai!" << endl;
		}
	} while (m <= 0 && n <= 0);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << "Nhap vao a[" << i << "][" << j << "] = ";
			cin >> a[i][j];
		}
	}
}
void xuatMangSoThuc2D(double a[][MAX], int m, int n) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			cout << a[i][j] << "\t";
		}
		cout << endl;
	}
}
void sapXepDungMangPhu(double a[][MAX], int m, int n, double b[][MAX]) {
	int b0[MAX];
	int k = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			b0[k++] = a[i][j]; 
		}
	}
	for (int i = 0; i < k - 1; i++) {
		for (int j = i + 1; j < k; j++) {
			if (b0[i] > b0[j]) {
				double temp = b0[i];
				b0[i] = b0[j];
				b0[j] = temp;
			}
		}
	} 
	k = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			b[i][j] = b0[k++];
		}
	}
	cout << "Mang B la: " << endl;
	xuatMangSoThuc2D(b, m, n);
}
void sapXepKhongDungMangPhu(double a[][MAX], int m, int n) {
	for (int j = 0; j < n; j++) {
		for (int i = 0; i < m - 1; i++) {
			for (int i1 = i + 1; i1 < m; i1++) {
				if (a[i1][j] < a[i][j]) {
					double temp = a[i1][j];
					a[i1][j] = a[i][j];
					a[i][j] = temp;
				}
			}
		}
	}
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n - 1; j++) {
			for (int j1 = j + 1; j1 < n; j1++) {
				if (a[i][j1] < a[i][j]) {
					double temp = a[i][j1];
					a[i][j1] = a[i][j];
					a[i][j] = temp;
				}
			}
		}
	}
	xuatMangSoThuc2D(a, m, n);
}
// Bai 3
bool kiemTraDiemYenNgua(int a[][MAX], int m, int n, int current_row, int current_column) {
	bool k = true;
	for (int i = 0; i < m; i++) {
		if (a[i][current_column] < a[current_row][current_column]) {
			k = false;
			break;
		}
	}
	for (int j = 0; j < n; j++) {
		if (a[current_row][j] > a[current_row][current_column]) {
			k = false;
			break;
		}
	}
	return k; 
}
void xuatDiemYenNgua(int a[][MAX], int m, int n) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			if (kiemTraDiemYenNgua(a, m, n, i, j)) {
				cout << "a[" << i << "][" << j << "] = " << a[i][j] << endl;
			}
		}
	}
}
// Bai 4
bool kiemTraPhanTuCoNghiaThuocMang(int a[][MAX], int m, int n, int current_row, int current_column) {
	if (current_row >= 0 && current_row < m && current_column >= 0 && current_column < n) {
		return true;
	}
	else {
		return false;
	}
}
int demSoLuongPhanTuDuongXungQuanh(int a[][MAX], int m, int n, int current_row, int current_column) {
	int dem = 0;
	if (a[current_row][current_column] > 0) {
		dem--;
	}
	for (int i = current_row - 1; i <= current_row + 1; i++) {
		for (int j = current_column - 1; j <= current_column + 1; j++) {
			if (a[i][j] > 0 && kiemTraPhanTuCoNghiaThuocMang(a, m, n, i, j)) {
				dem++;
			}
		}
	}
	return dem;
}
void xayDungMaTranB(int a[][MAX], int m, int n, int b[][MAX]) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			b[i][j] = demSoLuongPhanTuDuongXungQuanh(a, m, n, i, j);
		}
	}
	xuatMangSoNguyen2D(b, m, n);
}
// Bai 5
int tongCuaDong(int a[][MAX], int m, int n, int ofrow) {
	int sumof = 0;
	for (int j = 0; j < n; j++) {
		sumof += a[ofrow][j];
	}
	return sumof;
}
void sapXepDongNhoDenLon(int a[][MAX], int m, int n) {
	for (int i = 0; i < m-1; i++) {
		for (int i1 = i + 1; i1 < m; i1++) {
			if (tongCuaDong(a, m, n, i1) < tongCuaDong(a, m, n, i)) {
				for (int j = 0; j < n; j++) {
					int temp = a[i][j];
					a[i][j] = a[i1][j];
					a[i1][j] = temp;
				}
			}
		}
	}
}
