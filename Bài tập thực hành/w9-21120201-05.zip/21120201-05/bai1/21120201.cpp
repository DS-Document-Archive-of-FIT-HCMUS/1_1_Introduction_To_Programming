#include "Function.h"
int main() {
	int choice;
	while (true) {
		cout << "1. Nhap, xuat mang so nguyen va tim phan tu min max" << endl;
		cout << "2. Nhap, xuat mang so thuc va sap xep tang dan theo 2 cach" << endl;
		cout << "3. Xac dinh tat ca cac diem yen ngua co trong mang" << endl;
		cout << "4. Xay dung ma tran B, biet B[i][j] = so phan tu duong xung quanh A[i][j]" << endl;
		cout << "5. Sap xep ma tran sao cho dong co tong lon hon nam duoi dong co tong nho hon" << endl;
		cout << "0. Exit" << endl;
		cout << "Nhap lua chon cua ban la: ";
		cin >> choice;
		if (choice == 1) {
			int a1[MAX][MAX];
			int m1, n1;
			nhapMangSoNguyen2D(a1, m1, n1);
			xuatMangSoNguyen2D(a1, m1, n1);
			cout << "Phan tu lon nhat cua mang la: " << phanTuLonNhat(a1, m1, n1) << endl;
			cout << "Phan tu nho nhat cua mang la: " << phanTuNhoNhat(a1, m1, n1) << endl;
		}
		else if (choice == 2) {
			double a2[MAX][MAX];
			double b2[MAX][MAX];
			int m2, n2;
			nhapMangSoThuc2D(a2, m2, n2);
			xuatMangSoThuc2D(a2, m2, n2);
			cout << "Cach 1: Dung mang phu" << endl;
			sapXepDungMangPhu(a2, m2, n2, b2);
			cout << "Cach 2: Khong dung mang phu" << endl;
			sapXepKhongDungMangPhu(a2, m2, n2);
		}
		else if (choice == 3) {
			int a3[MAX][MAX];
			int m3, n3;
			nhapMangSoNguyen2D(a3, m3, n3);
			xuatMangSoNguyen2D(a3, m3, n3);
			cout << "Cac diem yen ngua cua mang la: " << endl;
			xuatDiemYenNgua(a3, m3, n3);
		}
		else if (choice == 4) {
			int a4[MAX][MAX];
			int m4, n4;
			int b4[MAX][MAX];
			nhapMangSoNguyen2D(a4, m4, n4);
			xuatMangSoNguyen2D(a4, m4, n4);
			cout << "Mang B thu duoc la: " << endl;
			xayDungMaTranB(a4, m4, n4, b4);
		}
		else if (choice == 5) {
			int a5[MAX][MAX];
			int m5, n5;
			nhapMangSoNguyen2D(a5, m5, n5);
			xuatMangSoNguyen2D(a5, m5, n5);
			cout << "Mang sau khi sap xep la: " << endl;
			sapXepDongNhoDenLon(a5, m5, n5);
			xuatMangSoNguyen2D(a5, m5, n5);
		}
		else if (choice == 0) {
			cout << "Ket thuc" << endl;
			break;
		}
		else {
			cout << "Gia tri khong thoa, moi ban nhap lai!" << endl;
		}
	}
	return 0;
}