#include <stdio.h>
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Tren lop: Bai tap 2
int main() {
	int a, b;
	printf("Nhap a,b theo thu tu= ");
	scanf_s("%d %d", &a, &b);
	float thuong;
	thuong = 1.0 * a / b;
	printf("Tong 2 so la: %d \n", a + b);
	printf("Hieu 2 so la: %d \n", a - b); 
	printf("Tich 2 so la: %d \n", a * b);
	printf("Thuong 2 so la: %f \n", thuong);
	return 0;
}