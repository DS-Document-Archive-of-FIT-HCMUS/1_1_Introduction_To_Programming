#include <iostream>
using namespace std;
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Tren lop: Bai tap 3
int main() {
	char x;
	cout << "Nhap ky tu x la " ;
	cin >> x;
	cout << endl;
	cout << "Ky tu do la: " << x << endl;
	cout << "Ma ASCII la: " << int(x);
	return 0;
}