#include <stdio.h>
// MSSV: 21120201
// Ten: Bui Dinh Bao
// Tren lop: Bai tap 4
int main() {
	float x, A ;
	printf("Nhap so thuc x=");
	scanf_s("%f", &x);
	A = 3 * x * x * x - 2 * x * x;
	printf("Ket qua A=%0.2f", A); 
	return 0;
}